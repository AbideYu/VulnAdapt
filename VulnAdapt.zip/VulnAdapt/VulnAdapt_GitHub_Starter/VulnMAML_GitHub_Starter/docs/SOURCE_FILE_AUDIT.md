# Source-file audit

The following materials were recovered from the author's experiment directory under `E:/Users/Sheriffleo/Desktop/新建文件夹`.

## Found

- Main implementation: `maml_pipeline.py`.
- Final processed JSON datasets and label maps for Nim, Rust, C, Java, and Python.
- Final `train_config.json`, `split_info.json`, and `final_report.json` files for all five languages.
- Supervised baseline script for LR, SVM, MLP, and XGBoost.
- Pretrained-code-model baseline script for CodeBERT, GraphCodeBERT, and UniXcoder.
- ProtoNet and Reptile comparison script.
- Feature-module switches for removal and single-module ablations.

The exact processed-data filenames, sizes, and SHA-256 values are recorded in `data/manifest.csv`. The paper configuration and result files are copied under `results/paper/`.

## Not found as complete release-ready artifacts

- End-to-end raw-source parser and extraction pipeline that creates `nodes`, security-anchor annotations, `key_skeleton`, and `template_family`.
- Exact raw-record selection lists for SARD, ReposVul, RustSec, and Nim.
- Full provenance and construction protocol for the supplementary CVE-pattern samples.
- Dedicated RQ4 timing program.
- Confirmed random seeds and complete machine-readable outputs for all RQ3 repetitions.
- Exact paper-run environment export and complete hardware record.
- Final publication metadata, GitHub URL, author list, and dataset redistribution decisions.

These gaps are detailed in `docs/MISSING_INFORMATION.md`.
