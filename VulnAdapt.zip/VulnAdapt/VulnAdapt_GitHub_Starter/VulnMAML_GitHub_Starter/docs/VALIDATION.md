# Package validation

The starter package was checked on 2026-08-19 before delivery.

## Completed checks

- All Python files passed `python -m compileall`.
- All five YAML configurations loaded successfully.
- `CITATION.cff` and `environment.yml` passed YAML parsing.
- The three PowerShell launchers passed syntax parsing.
- The processed Rust dataset passed schema validation: 114 samples, 114 label entries, and 114 sample identifiers.
- A one-epoch, 3-way 1-shot 1-query CPU smoke run completed from processed Rust JSON and produced a checkpoint, split record, feature file, and final report.
- `test.py` reloaded the smoke-run checkpoint and evaluated its recorded test split successfully.

The smoke run verifies the execution path only. Its metrics are not paper results. A clean rerun of all five full configurations remains required after the final environment and publishable data package are fixed.

