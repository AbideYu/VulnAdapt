# Reproduction protocol

## Main experiment

1. Obtain or construct the processed dataset described in `data/README.md`.
2. Confirm its SHA-256 hash against `data/manifest.csv`.
3. Place sample and label JSON files in the standard repository paths.
4. Install the pinned environment.
5. Validate the processed data.
6. Run language-specific training.
7. Re-evaluate the saved checkpoint with the recorded test split.
8. Compare `final_report.json` with `results/paper/reports/<language>.json`.

Example:

```bash
python preprocess.py --config configs/nim.yaml
python train.py --config configs/nim.yaml
python test.py --config configs/nim.yaml
```

## Files produced by training

| File | Purpose |
|---|---|
| `best_model.pt` | Selected checkpoint, model configuration, and split metadata |
| `maml_ready_features.npz` | Fixed-dimensional feature tensors and metadata |
| `vocabs.json` | Training-only feature vocabularies |
| `sample_features.jsonl` | Per-sample vectorisation record |
| `split_info.json` | Exact indices, identifiers, grouping audit, and split counts |
| `train_config.json` | Fully resolved run configuration |
| `train_history.json` | Epoch-level training and validation metrics |
| `final_report.json` | Episode-averaged test metrics |

## Exact split verification

The pipeline can regenerate a deterministic split from seed 42, but strict paper-number verification should compare or reuse the archived split metadata under `results/paper/splits/`. Any change to processed sample order, template-family identifiers, grouping logic, or data cleaning can change the split.

## Result tolerance

CPU and CUDA floating-point execution can produce small differences. The repository should report the tolerance used to judge reproduction after the authors rerun all language tasks in a clean environment. No tolerance is asserted in this starter package.

## Baselines

- `baselines/supervised.py`: LR, SVM, MLP, and XGBoost with the same structural security semantic features.
- `baselines/pretrained_code_models.py`: CodeBERT, GraphCodeBERT, and UniXcoder frozen/unfrozen comparisons.
- `baselines/protonet_reptile.py`: ProtoNet and Reptile comparisons.

These scripts were copied from the audited experiment directory. They still expose their original all-in-one CLIs and should receive short wrapper scripts and verified per-language commands before the public release.

