# Verified paper configuration

This document records values recovered from the available `train_config.json`, `split_info.json`, `final_report.json`, and the main training code. It distinguishes verified settings from assumptions.

## Task boundary

- Five languages are trained and tested independently.
- Samples, feature vocabularies, and model parameters are not shared between languages.
- The task is multi-class vulnerability-type classification including the `Safe` class.
- `n_way: 0` in the CLI means all classes available in the current language dataset.

## Shared model and optimisation settings

| Setting | Value |
|---|---|
| Encoder/classifier | Two-hidden-layer MLP |
| Hidden dimensions | 64, 32 |
| Dropout | 0.1 |
| Meta-learning | First-order MAML |
| Inner updates | 1 |
| Inner learning rate | 0.01 |
| Inner update scope | All parameters |
| Outer optimiser | Adam |
| Outer learning rate | 0.001 |
| Weight decay | 0.0001 |
| Gradient clipping | 5.0 |
| Outer updates | 200 |
| Episodes per meta-batch | 4 |
| Total sampled training episodes | 800 |
| Validation episodes | 30 |
| Test episodes | 50 |
| Checkpoint metric | Validation Macro-F1 |
| Main random seed | 42 |
| Skeleton field | `key_skeleton` |
| Grouping mode | `template_family` |
| Group split scope | `global` |
| Feature vocabulary | Training split only |
| Module gates | Disabled in the reported full model |
| Summary flags | Disabled |

## Language-specific settings and observed splits

| Language | Classes | Main task | Requested val/test/min-train per class | Actual train/val/test samples | Device recorded | Macro-F1 (%) |
|---|---:|---|---|---|---|---:|
| Nim | 9 | 9-way 1-shot 3-query | 10/10/24 | 325/90/90 | CPU | 84.28 |
| Rust | 7 | 7-way 1-shot 1-query | 1/1/2 | 100/0/14 | CPU | 80.95 |
| C | 9 | 9-way 1-shot 3-query | 10/10/24 | 156/36/36 | CPU | 81.43 |
| Java | 9 | 9-way 1-shot 3-query | 3/3/5 | 156/36/36 | CUDA | 84.13 |
| Python | 9 | 9-way 1-shot 3-query | 3/3/5 | 156/36/36 | CUDA | 84.13 |

The split procedure is adaptive. Consequently, the actual C/Java/Python held-out count is four samples per class despite some requested values being three or ten. The Rust run has two test samples per class and no held-out validation set.

## Rust checkpoint-selection limitation

The verified Rust run records:

- `has_val: false`;
- `proxy_val_used: true`;
- `val_mode: train_proxy`.

The checkpoint was therefore selected using episodes sampled from the training subset. The test subset remained separate, but model selection did not use an independent validation set. This must be disclosed in the repository and paper limitations.

## Reported class spaces

The exact label order is stored in `results/paper/configs/<language>.json`. Each language has its own label space, and labels are mapped to contiguous identifiers within that dataset.

## Sensitivity study

The paper description specifies:

- languages: Nim and Rust;
- support-size study: 3-way, 1-query, with 1/3/5-shot;
- class-way study: 1-shot, 1-query, with 2/3/5-way;
- three independent runs per setting.

Only seed 42 is verified from the main experiment files. Seeds 43 and 44 in the provided sensitivity launcher are provisional reproducibility defaults and must be replaced if the original three sensitivity-run seeds differ.

## Efficiency study

The paper description specifies 10 warm-up episodes followed by 100 measured episodes. Timing uses cached feature tensors and excludes feature extraction. A dedicated timing script and complete hardware record were not found in the audited directory.

