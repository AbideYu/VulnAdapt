# Information still required before GitHub release

The following items could not be confirmed from the audited files. Supply them before describing the repository as fully reproducible.

## Publication metadata

- [ ] Final method/repository name: `VulnMAML` or `VulnAdapt`.
- [ ] Final paper title.
- [ ] Full author names and order.
- [ ] ORCID identifiers, if used.
- [ ] Conference/journal name, year, pages, DOI, and paper URL.
- [ ] Final GitHub owner and repository URL.

## Environment and hardware

- [ ] `pip freeze` or Conda export from the exact environment used for final paper runs.
- [ ] Operating system edition and version.
- [ ] CPU model and RAM.
- [ ] GPU model and VRAM.
- [ ] NVIDIA driver and CUDA runtime versions.
- [ ] Confirmation that the observed Python 3.14.2 / PyTorch 2.11.0+cu128 environment is the paper-run environment.

## End-to-end preprocessing

- [ ] Script that downloads/selects raw SARD cases used for C and Java.
- [ ] Script that selects the 228 Python samples from ReposVul.
- [ ] Script that resolves RustSec advisories to the 114 Rust code samples.
- [ ] Complete source list for the 505 Nim samples.
- [ ] Exact CVE identifiers and protocol used to construct supplementary samples.
- [ ] Parser/rule code that converts raw source code to the `nodes` field.
- [ ] Security-anchor rules and their provenance.
- [ ] Program-skeleton construction code.
- [ ] Label mapping and manual review protocol.
- [ ] Explanation of how `template_family` is assigned before grouped splitting.

## Data and licensing

- [ ] License/redistribution decision for each processed dataset.
- [ ] License for manually constructed Nim samples.
- [ ] Attribution files required by SARD, ReposVul, and RustSec.
- [ ] Decision to host processed data, release only IDs/scripts, or use an archival service.
- [ ] Verification that code snippets do not contain personal or confidential data.

## Experimental reproduction

- [ ] Original seeds for all three repetitions in the RQ3 sensitivity experiments.
- [ ] Dedicated RQ4 timing script.
- [ ] Exact hardware used for timing results.
- [ ] Commands/configurations for LR, SVM, MLP, XGBoost, ProtoNet, Reptile, CodeBERT, GraphCodeBERT, and UniXcoder.
- [ ] Checkpoints or a decision not to publish them.
- [ ] Machine-readable outputs for every ablation and sensitivity run.
- [ ] A clean-environment rerun confirming that the five main Macro-F1 values are reproducible.

## Items found and already included

- [x] Main first-order MAML pipeline.
- [x] Five processed dataset filenames and SHA-256 hashes.
- [x] Five main language configurations.
- [x] Exact main split records.
- [x] Main final reports matching the paper values.
- [x] Feature-ablation switches.
- [x] Supervised, pretrained-model, ProtoNet, and Reptile experiment scripts.

