# Data preparation

## Sources

| Language | Source used in the study | Official resource |
|---|---|---|
| C | NIST Software Assurance Reference Dataset (SARD) | https://samate.nist.gov/SARD/ |
| Java | NIST Software Assurance Reference Dataset (SARD) | https://samate.nist.gov/SARD/ |
| Python | ReposVul | https://github.com/Eshe0922/ReposVul |
| Rust | RustSec Advisory Database | https://github.com/rustsec/advisory-db |
| Nim | Public vulnerability records plus supplementary samples constructed from real CVE trigger patterns | Exact record/CVE list still required from the authors |

The processed datasets are not bundled in this starter package because their redistribution terms and the license of the manually constructed supplementary samples still require confirmation.

## Expected layout

```text
data/processed/
├── c/samples.json
├── c/labels.json
├── java/samples.json
├── java/labels.json
├── nim/samples.json
├── nim/labels.json
├── python/samples.json
├── python/labels.json
├── rust/samples.json
└── rust/labels.json
```

The exact local source filenames and SHA-256 hashes found during the repository audit are recorded in [`manifest.csv`](manifest.csv). Rename or copy the files to the standard paths above before running the commands in the root README.

## Processed sample schema

The top-level dataset JSON must be a list of sample objects. The verified datasets contain the following fields:

```json
{
  "sample_id": "s0001__example",
  "proc_name": "example_function",
  "code": "source code text",
  "dataset_label": "Safe_or_vulnerability_type",
  "binary_label": 0,
  "language": "Nim_or_Rust_or_C_or_Java_or_Python",
  "nodes": [
    {
      "type": "node type",
      "name": "node or anchor payload"
    }
  ],
  "key_skeleton": "abstracted local operation sequence",
  "anchor_skeleton": "optional anchor-oriented sequence",
  "template_family": "group identifier used for leakage-aware splitting"
}
```

The pipeline requires:

- a top-level JSON list;
- `nodes` for key-node and security-anchor feature construction;
- one usable skeleton field (`key_skeleton` in the paper configurations);
- `sample_id` or `proc_name`;
- labels either inside each sample or in a separate label map.

The verified label JSON stores the mapping under `labels_by_sample_id` and keeps
`label_to_id`, `id_to_label`, class counts, and metadata at the top level. A
direct `sample_id`/`proc_name` to label mapping is also accepted. `Safe`
participates in episode sampling and Macro-F1 computation.

## Preprocessing boundary

The available `maml_pipeline.py` begins from **processed JSON samples** containing `nodes` and skeleton fields. It normalises and vectorises key nodes, security anchors, and program skeletons, but it does not independently reconstruct all these fields from raw source files.

To support end-to-end reproduction from SARD, ReposVul, RustSec, and the Nim source records, the public repository still needs:

1. raw record selection and filtering scripts;
2. the language-specific parser or extraction rules that generate `nodes`;
3. the security-anchor rule dictionaries;
4. the program-skeleton construction script;
5. the exact Nim CVE/record list and supplementary-sample construction protocol.

Until these are added, the included code reproduces experiments from the processed JSON level.

## Data splits

The paper runs use global template-family grouping. Feature vocabularies are built only from the resulting training indices. The exact split indices and identifiers are available under `results/paper/splits/`.

Do not regenerate a random split when verifying the paper numbers. Use the recorded split metadata or the same seed and grouping code.
