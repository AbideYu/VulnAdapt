"""Configuration loading and translation to the verified pipeline CLI."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


def load_config(path: str | Path) -> Dict[str, Any]:
    config_path = Path(path).resolve()
    with config_path.open("r", encoding="utf-8") as handle:
        config = yaml.safe_load(handle)
    if not isinstance(config, dict):
        raise ValueError(f"Configuration must be a YAML mapping: {config_path}")
    config["_config_path"] = str(config_path)
    config["_repo_root"] = str(config_path.parent.parent)
    return config


def resolve_repo_path(config: Dict[str, Any], value: str) -> str:
    path = Path(value)
    if path.is_absolute():
        return str(path)
    return str((Path(config["_repo_root"]) / path).resolve())


def with_overrides(
    config: Dict[str, Any],
    *,
    n_way: Optional[int] = None,
    k_shot: Optional[int] = None,
    q_query: Optional[int] = None,
    seed: Optional[int] = None,
    output_dir: Optional[str] = None,
    disable_key_nodes: bool = False,
    disable_anchors: bool = False,
    disable_skeleton: bool = False,
    force_cpu: bool = False,
) -> Dict[str, Any]:
    cfg = deepcopy(config)
    if n_way is not None:
        cfg["episode"]["n_way"] = int(n_way)
    if k_shot is not None:
        cfg["episode"]["k_shot"] = int(k_shot)
    if q_query is not None:
        cfg["episode"]["q_query"] = int(q_query)
    if seed is not None:
        cfg["training"]["seed"] = int(seed)
    if output_dir is not None:
        cfg["output_dir"] = output_dir
    if disable_key_nodes:
        cfg["features"]["key_nodes"] = False
    if disable_anchors:
        cfg["features"]["security_anchors"] = False
    if disable_skeleton:
        cfg["features"]["program_skeleton"] = False
    if force_cpu:
        cfg.setdefault("runtime", {})["cpu"] = True
    return cfg


def _add_value(argv: List[str], flag: str, value: Any) -> None:
    argv.extend([flag, str(value)])


def build_train_argv(config: Dict[str, Any]) -> List[str]:
    data = config["data"]
    episode = config["episode"]
    split = config["split"]
    model = config["model"]
    training = config["training"]
    features = config["features"]
    runtime = config.get("runtime", {})

    argv: List[str] = ["train_json"]
    _add_value(argv, "--input_json", resolve_repo_path(config, data["input_json"]))
    if data.get("labels_json"):
        _add_value(argv, "--labels_json", resolve_repo_path(config, data["labels_json"]))
    _add_value(argv, "--output_dir", resolve_repo_path(config, config["output_dir"]))
    _add_value(argv, "--skeleton_field", data.get("skeleton_field", "key_skeleton"))
    _add_value(argv, "--group_mode", split.get("group_mode", "template_family"))
    _add_value(argv, "--group_split_scope", split.get("group_split_scope", "global"))

    mappings = [
        ("--n_way", episode["n_way"]),
        ("--k_shot", episode["k_shot"]),
        ("--q_query", episode["q_query"]),
        ("--meta_epochs", training["meta_epochs"]),
        ("--meta_batch_size", training["meta_batch_size"]),
        ("--eval_episodes", training["eval_episodes"]),
        ("--test_episodes", training["test_episodes"]),
        ("--val_per_class", split["val_per_class"]),
        ("--test_per_class", split["test_per_class"]),
        ("--min_train_per_class", split["min_train_per_class"]),
        ("--inner_steps", training["inner_steps"]),
        ("--inner_lr", training["inner_lr"]),
        ("--meta_lr", training["meta_lr"]),
        ("--weight_decay", training["weight_decay"]),
        ("--hidden_dim", model["hidden_dim"]),
        ("--embed_dim", model["embed_dim"]),
        ("--dropout", model["dropout"]),
        ("--inner_update_scope", training["inner_update_scope"]),
        ("--grad_clip", training["grad_clip"]),
        ("--seed", training["seed"]),
        ("--log_every", training["log_every"]),
        ("--monitor_metric", training["monitor_metric"]),
        ("--module_dropout", model.get("module_dropout", 0.0)),
        ("--gate_balance_lambda", model.get("gate_balance_lambda", 0.0)),
    ]
    for flag, value in mappings:
        _add_value(argv, flag, value)

    if not split.get("group_split", True):
        argv.append("--disable_group_split")
    if split.get("force_no_val", False):
        argv.append("--force_no_val")
    if model.get("disable_module_gates", True):
        argv.append("--disable_module_gates")
    if model.get("disable_adaptive_module_gates", False):
        argv.append("--disable_adaptive_module_gates")
    if runtime.get("cpu", False):
        argv.append("--cpu")
    if not features.get("key_nodes", True):
        argv.append("--disable_key_nodes")
    if not features.get("security_anchors", True):
        argv.append("--disable_anchors")
    if not features.get("program_skeleton", True):
        argv.append("--disable_skeleton")
    return argv
