$ErrorActionPreference = "Stop"

foreach ($language in @("nim", "rust")) {
    foreach ($seed in @(42, 43, 44)) {
        foreach ($shot in @(1, 3, 5)) {
            python train.py --config "configs/$language.yaml" `
                --n-way 3 --k-shot $shot --q-query 1 --seed $seed `
                --output-dir "outputs/$language/sensitivity/3way_${shot}shot_seed${seed}"
        }
        foreach ($way in @(2, 3, 5)) {
            python train.py --config "configs/$language.yaml" `
                --n-way $way --k-shot 1 --q-query 1 --seed $seed `
                --output-dir "outputs/$language/sensitivity/${way}way_1shot_seed${seed}"
        }
    }
}

