#!/usr/bin/env bash
set -euo pipefail

for language in nim rust c java python; do
  python preprocess.py --config "configs/${language}.yaml"
  python train.py --config "configs/${language}.yaml"
  python test.py --config "configs/${language}.yaml"
done

