#!/usr/bin/env bash
set -euo pipefail

languages=(nim rust c java python)

for language in "${languages[@]}"; do
  python train.py --config "configs/${language}.yaml" \
    --output-dir "outputs/${language}/wo_key_nodes" --disable-key-nodes
  python train.py --config "configs/${language}.yaml" \
    --output-dir "outputs/${language}/wo_security_anchors" --disable-anchors
  python train.py --config "configs/${language}.yaml" \
    --output-dir "outputs/${language}/wo_program_skeleton" --disable-skeleton

  python train.py --config "configs/${language}.yaml" \
    --output-dir "outputs/${language}/only_key_nodes" \
    --disable-anchors --disable-skeleton
  python train.py --config "configs/${language}.yaml" \
    --output-dir "outputs/${language}/only_security_anchors" \
    --disable-key-nodes --disable-skeleton
  python train.py --config "configs/${language}.yaml" \
    --output-dir "outputs/${language}/only_program_skeleton" \
    --disable-key-nodes --disable-anchors
done

