#!/usr/bin/env bash
set -euo pipefail

for language in nim rust; do
  for seed in 42 43 44; do
    for shot in 1 3 5; do
      python train.py --config "configs/${language}.yaml" \
        --n-way 3 --k-shot "${shot}" --q-query 1 --seed "${seed}" \
        --output-dir "outputs/${language}/sensitivity/3way_${shot}shot_seed${seed}"
    done
    for way in 2 3 5; do
      python train.py --config "configs/${language}.yaml" \
        --n-way "${way}" --k-shot 1 --q-query 1 --seed "${seed}" \
        --output-dir "outputs/${language}/sensitivity/${way}way_1shot_seed${seed}"
    done
  done
done

