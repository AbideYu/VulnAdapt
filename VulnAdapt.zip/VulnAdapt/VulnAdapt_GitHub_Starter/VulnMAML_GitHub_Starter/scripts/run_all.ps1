$ErrorActionPreference = "Stop"

foreach ($language in @("nim", "rust", "c", "java", "python")) {
    python preprocess.py --config "configs/$language.yaml"
    python train.py --config "configs/$language.yaml"
    python test.py --config "configs/$language.yaml"
}

