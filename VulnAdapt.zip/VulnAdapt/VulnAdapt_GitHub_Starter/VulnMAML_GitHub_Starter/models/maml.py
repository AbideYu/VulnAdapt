"""First-order MAML model interface backed by the verified pipeline."""

from vulnmaml.pipeline import (
    EpisodeSampler,
    MAMLMLP,
    adapt_model,
    evaluate_episodes,
    predict_with_adaptation,
)

__all__ = [
    "EpisodeSampler",
    "MAMLMLP",
    "adapt_model",
    "evaluate_episodes",
    "predict_with_adaptation",
]

