"""Re-evaluate a trained checkpoint on the recorded test split."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from vulnmaml.config import load_config, resolve_repo_path
from vulnmaml.pipeline import (
    EpisodeSampler,
    MAMLMLP,
    evaluate_episodes,
    load_feature_npz_meta,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--output-dir")
    parser.add_argument("--episodes", type=int)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()

    config_file = load_config(args.config)
    output_dir = Path(
        resolve_repo_path(config_file, args.output_dir or config_file["output_dir"])
    )
    checkpoint_path = output_dir / "best_model.pt"
    feature_path = output_dir / "maml_ready_features.npz"
    if not checkpoint_path.exists() or not feature_path.exists():
        raise FileNotFoundError(
            f"Run training first. Expected {checkpoint_path} and {feature_path}."
        )

    device = "cpu" if args.cpu or not torch.cuda.is_available() else "cuda"
    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    config = checkpoint["config"]
    split_info = checkpoint["split_info"]
    X, y, _names, _groups, _labels, _hashes, _families = load_feature_npz_meta(
        str(feature_path)
    )

    feature_dims = config.get("feature_block_dims")
    model = MAMLMLP(
        input_dim=int(config["input_dim"]),
        hidden_dim=int(config["hidden_dim"]),
        embed_dim=int(config["embed_dim"]),
        dropout=float(config["dropout"]),
        n_classes=int(config["n_classes"]),
        feature_block_dims=feature_dims,
        use_module_gates=not bool(config.get("disable_module_gates", False)),
        adaptive_module_gates=not bool(
            config.get("disable_adaptive_module_gates", False)
        ),
        module_dropout=float(config.get("module_dropout_used", 0.0)),
    ).to(device)
    model.load_state_dict(checkpoint["model_state"])

    sampler = EpisodeSampler(
        X,
        y,
        list(split_info["test_idx"]),
        n_way=int(config["n_way_used"]),
        k_shot=int(config["k_shot"]),
        q_query=int(config["q_query"]),
        seed=int(config["seed"]) + 37,
    )
    metrics = evaluate_episodes(
        model,
        sampler,
        num_episodes=args.episodes or int(config["test_episodes"]),
        inner_steps=int(config["inner_steps"]),
        inner_lr=float(config["inner_lr"]),
        update_scope=str(config["inner_update_scope"]),
        device=device,
    )
    print(json.dumps(metrics, indent=2))


if __name__ == "__main__":
    main()

