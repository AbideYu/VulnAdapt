"""Program-skeleton feature interface backed by the verified pipeline."""

from vulnmaml.pipeline import (
    build_skeleton_bigram_vocab,
    extract_normalized_skeleton_tokens,
    normalize_skeleton_token,
    parse_skeleton,
    skeleton_to_bigrams,
    vectorize_skeleton_bigrams,
)

__all__ = [
    "build_skeleton_bigram_vocab",
    "extract_normalized_skeleton_tokens",
    "normalize_skeleton_token",
    "parse_skeleton",
    "skeleton_to_bigrams",
    "vectorize_skeleton_bigrams",
]

