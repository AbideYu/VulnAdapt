"""Security-anchor feature interface backed by the verified pipeline."""

from vulnmaml.pipeline import (
    build_anchor_vocab,
    extract_anchor_features,
    extract_anchors,
    normalize_anchor_token,
    vectorize_anchors,
)

__all__ = [
    "build_anchor_vocab",
    "extract_anchor_features",
    "extract_anchors",
    "normalize_anchor_token",
    "vectorize_anchors",
]

