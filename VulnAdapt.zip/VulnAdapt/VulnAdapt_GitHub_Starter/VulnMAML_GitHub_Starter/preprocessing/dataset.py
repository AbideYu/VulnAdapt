"""Processed-dataset loading interface backed by the verified pipeline."""

from vulnmaml.pipeline import (
    Sample,
    load_labels,
    load_samples,
    resolve_sample_id,
    select_skeleton_value,
)

__all__ = [
    "Sample",
    "load_labels",
    "load_samples",
    "resolve_sample_id",
    "select_skeleton_value",
]

