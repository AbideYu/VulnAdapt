"""Template-grouped split interface backed by the verified pipeline."""

from vulnmaml.pipeline import (
    analyze_split_overlap,
    choose_group_id,
    compute_split_plan,
    infer_template_family,
    stratified_split_indices,
)

__all__ = [
    "analyze_split_overlap",
    "choose_group_id",
    "compute_split_plan",
    "infer_template_family",
    "stratified_split_indices",
]

