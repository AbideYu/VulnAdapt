"""Train VulnMAML from a language-specific YAML configuration."""

from __future__ import annotations

import argparse
import sys

from vulnmaml import pipeline
from vulnmaml.config import build_train_argv, load_config, with_overrides


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--n-way", type=int)
    parser.add_argument("--k-shot", type=int)
    parser.add_argument("--q-query", type=int)
    parser.add_argument("--seed", type=int)
    parser.add_argument("--output-dir")
    parser.add_argument("--disable-key-nodes", action="store_true")
    parser.add_argument("--disable-anchors", action="store_true")
    parser.add_argument("--disable-skeleton", action="store_true")
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()

    config = load_config(args.config)
    config = with_overrides(
        config,
        n_way=args.n_way,
        k_shot=args.k_shot,
        q_query=args.q_query,
        seed=args.seed,
        output_dir=args.output_dir,
        disable_key_nodes=args.disable_key_nodes,
        disable_anchors=args.disable_anchors,
        disable_skeleton=args.disable_skeleton,
        force_cpu=args.cpu,
    )
    sys.argv = ["vulnmaml.pipeline", *build_train_argv(config)]
    pipeline.main()


if __name__ == "__main__":
    main()
