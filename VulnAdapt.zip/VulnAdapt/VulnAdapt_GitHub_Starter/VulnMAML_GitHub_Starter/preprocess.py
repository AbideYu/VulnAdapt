"""Validate processed VulnMAML JSON data before training.

The released training command constructs train-only vocabularies internally.
This validator deliberately does not construct a full-dataset vocabulary.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from vulnmaml.config import load_config, resolve_repo_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    args = parser.parse_args()

    config = load_config(args.config)
    data_cfg = config["data"]
    data_path = Path(resolve_repo_path(config, data_cfg["input_json"]))
    labels_path = Path(resolve_repo_path(config, data_cfg["labels_json"]))
    skeleton_field = data_cfg.get("skeleton_field", "key_skeleton")

    if not data_path.exists():
        raise FileNotFoundError(f"Dataset not found: {data_path}")
    if not labels_path.exists():
        raise FileNotFoundError(f"Label map not found: {labels_path}")

    with data_path.open("r", encoding="utf-8") as handle:
        samples = json.load(handle)
    with labels_path.open("r", encoding="utf-8") as handle:
        labels = json.load(handle)

    if not isinstance(samples, list) or not samples:
        raise ValueError("The dataset JSON must be a non-empty list.")
    if not isinstance(labels, dict):
        raise ValueError("The label JSON must be a JSON object.")

    # The verified label files store the actual mapping under
    # ``labels_by_sample_id`` and keep metadata alongside it.  A direct
    # sample-id-to-label mapping is also accepted for simpler releases.
    label_mapping = labels.get("labels_by_sample_id", labels)
    if not isinstance(label_mapping, dict):
        raise ValueError(
            "The label JSON must contain a 'labels_by_sample_id' object "
            "or directly map sample identifiers to labels."
        )

    required = {"nodes", skeleton_field}
    missing = []
    identifiers = set()
    for index, sample in enumerate(samples):
        if not isinstance(sample, dict):
            raise ValueError(f"Sample {index} is not a JSON object.")
        absent = sorted(field for field in required if not sample.get(field))
        if absent:
            missing.append((index, absent))
        sample_id = sample.get("sample_id") or sample.get("proc_name")
        if sample_id:
            identifiers.add(str(sample_id))

    if missing:
        preview = ", ".join(f"{idx}:{fields}" for idx, fields in missing[:10])
        raise ValueError(f"{len(missing)} samples miss required feature fields ({preview}).")

    print(f"language={config['language']}")
    print(f"samples={len(samples)}")
    print(f"label_entries={len(label_mapping)}")
    print(f"samples_with_identifiers={len(identifiers)}")
    print(f"skeleton_field={skeleton_field}")
    print("validation=passed")


if __name__ == "__main__":
    main()
