"""Baseline implementations used in the paper experiments."""

