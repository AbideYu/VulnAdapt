#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
maml_pipeline_all_in_one.py

将 build_maml_features.py 与 train_maml_from_npz.py 合并为一个脚本，支持：
1. 从原始 JSON 直接构建特征
2. 从原始 JSON 直接训练 first-order MAML
3. 保留原有 NPZ 训练/预测入口
4. 支持使用已保存词表从 JSON 直接做 few-shot 预测

典型用法：

1) 直接从 JSON 训练：
python maml_pipeline_all_in_one.py train_json \
  --input_json nim_source_to_keynodes_anchors.json \
  --labels_json labels_poc.json \
  --output_dir outputs_maml

2) 仅构建特征：
python maml_pipeline_all_in_one.py build_features \
  --input_json nim_source_to_keynodes_anchors.json \
  --labels_json labels_poc.json \
  --output_dir outputs_features

3) 沿用旧流程，从 NPZ 训练：
python maml_pipeline_all_in_one.py train_npz \
  --input_npz outputs_features/maml_ready_features.npz \
  --output_dir outputs_maml

4) 从原始 JSON 直接 few-shot 预测（使用训练时保存的 vocabs.json）：
python maml_pipeline_all_in_one.py predict_json \
  --checkpoint outputs_maml/best_model.pt \
  --vocabs_json outputs_maml/vocabs.json \
  --support_json support.json \
  --support_labels_json support_labels.json \
  --query_json query.json \
  --output_json pred.json
"""

from __future__ import annotations

import argparse
import json
import math
import random
import re
import hashlib
from collections import OrderedDict, defaultdict, Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    from torch.func import functional_call
except Exception:
    from torch.nn.utils.stateless import functional_call  # type: ignore


# =========================
# Part A. Feature building
# =========================

DEFAULT_LABELS: Dict[str, Any] = {}
GLOBAL_LABEL_TO_ID: "OrderedDict[str, int]" = OrderedDict([
    ("Safe", 0),
    ("Acceptance_of_Extraneous_Untrusted Data", 1),
    ("Improper_Certificate_validation", 2),
    ("Improper_Input_Validation", 3),
    ("Improper_Neutralization_of CRLF_Sequences", 4),
    ("OS_Command_Injection", 5),
    ("PHP_Remote_FileInclusion", 6),
    ("Relative_Path_Traversal", 7),
    ("XSS", 8),
    ("SQL_Injection", 9),
    ("Improper_Authentication", 10),
    ("HTTP_Request_Smuggling", 11),
    ("Time-of-check_Time-of-use_(TOCTOU)_Race_Condition", 12),
    ("SSRF", 13),
    # Rust vulnerability labels (global reference only; training still uses per-dataset contiguous ids)
    ("Memory_Corruption", 14),
    ("Crypto_Failure", 15),
    ("Memory_Exposure", 16),
    ("Code_Execution", 17),
    ("Denial_Of_Service", 18),
    ("Format_Injection", 19),
    ("Privilege_Escalation", 20),
    ("Thread_Safety", 21),
    # Kotlin vulnerability labels (global reference only; training still uses per-dataset contiguous ids)
    ("Concurrent_Execution_Using_Shared_Resource_With_Improper_Synchronization", 22),
    ("Uncaught_Exception", 23),
    ("Improper_Handling_Of_Case_Sensitivity", 24),
    ("Missing_Serialization_Control_Element", 25),
])
GLOBAL_ID_TO_LABEL: Dict[str, str] = {str(v): k for k, v in GLOBAL_LABEL_TO_ID.items()}


SUMMARY_FLAG_NAMES = [
    "has_input_source",
    "has_command_binding",
    "has_command_construction",
    "has_command_execution",
    "has_network_request",
    "has_url_or_payload_construction",
    "has_response_parsing",
    "has_file_include",
    "has_path_construction",
    "has_archive_extraction",
    "has_file_write",
    "has_markup_rendering",
    "has_header_injection",
    "has_security_guard",
    "has_validation_check",
    "has_exception_recovery",
]

FEATURE_BLOCK_ORDER = ["key", "anchor", "skeleton", "summary"]

# Pre-trained code model baselines. These replace the hand-crafted
# key-node / anchor / skeleton feature extractor with a frozen encoder
# embedding extracted from raw code. The downstream MAML training and
# grouped split logic are kept unchanged for a fair feature-extractor
# comparison.
PLM_MODEL_NAMES: Dict[str, str] = {
    "codebert": "microsoft/codebert-base",
    "graphcodebert": "microsoft/graphcodebert-base",
    "unixcoder": "microsoft/unixcoder-base",
}
PLM_FEATURE_EXTRACTORS = tuple(PLM_MODEL_NAMES.keys())



def normalize_feature_switches(
    use_key_nodes: bool = True,
    use_anchors: bool = True,
    use_skeleton: bool = True,
    use_summary_flags: Optional[bool] = None,
    **_ignored: Any,
) -> Dict[str, bool]:
    use_key_nodes = bool(use_key_nodes)
    use_anchors = bool(use_anchors)
    use_skeleton = bool(use_skeleton)

    # RQ3-v2: summary flags are deliberately OFF by default.
    # They are derived from anchors and can make the "only anchors" ablation
    # stronger than the full model, which hides the contribution of key nodes
    # and skeletons. Enable them only if explicitly requested in code/config.
    if use_summary_flags is None:
        normalized_summary_flags = False
    else:
        normalized_summary_flags = bool(use_summary_flags) and use_anchors

    return {
        "use_key_nodes": use_key_nodes,
        "use_anchors": use_anchors,
        "use_skeleton": use_skeleton,
        "use_summary_flags": normalized_summary_flags,
    }


def feature_switches_to_tag(feature_switches: Dict[str, bool]) -> str:
    flags = normalize_feature_switches(
        use_key_nodes=feature_switches.get("use_key_nodes", True),
        use_anchors=feature_switches.get("use_anchors", True),
        use_skeleton=feature_switches.get("use_skeleton", True),
    )
    active = []
    if flags["use_key_nodes"]:
        active.append("key")
    if flags["use_anchors"]:
        active.append("anchors")
    if flags["use_skeleton"]:
        active.append("skeleton")
    if not active:
        return "none"
    return "+".join(active)



@dataclass
class Sample:
    sample_id: str
    proc_name: str
    code: str
    nodes: List[Dict[str, Any]]
    skeleton: str
    label: int
    notes: str = ""
    dataset_label: str = ""
    binary_label: Optional[int] = None
    skeleton_field_used: str = ""
    pair_group: str = ""
    pair_role: str = ""
    source_label: str = ""
    template_family: str = ""
    language: str = ""


def normalize_code_for_group(code: str) -> str:
    code = str(code or "").strip()
    code = code.replace("\r\n", "\n").replace("\r", "\n")
    code = re.sub(r"[ \t]+", " ", code)
    code = re.sub(r"\n+", "\n", code)
    return code.strip()


def make_code_group_id(code: str) -> str:
    norm = normalize_code_for_group(code)
    if not norm:
        return ""
    return hashlib.sha1(norm.encode("utf-8")).hexdigest()[:16]


RUST_DATASET_LABELS = {
    "Memory_Corruption",
    "Crypto_Failure",
    "Memory_Exposure",
    "Code_Execution",
    "Denial_Of_Service",
    "Format_Injection",
    "Privilege_Escalation",
    "Thread_Safety",
}

RUST_PREFIX_TEMPLATE_FAMILIES: "OrderedDict[str, str]" = OrderedDict([
    ("corrupt_", "Rust::unsafe_buffer_offset"),
    ("derive_", "Rust::fixed_bytes_derivation"),
    ("expose_", "Rust::buffer_to_string"),
    ("run_", "Rust::process_command"),
    ("exhaust_", "Rust::bounded_allocation"),
    ("render_", "Rust::template_rewrite"),
    ("can_access_", "Rust::authorization_check"),
    ("bump_", "Rust::shared_counter"),
])

KOTLIN_DATASET_LABELS = {
    "Concurrent_Execution_Using_Shared_Resource_With_Improper_Synchronization",
    "Uncaught_Exception",
    "Improper_Handling_Of_Case_Sensitivity",
    "Improper_Input_Validation",
    "Missing_Serialization_Control_Element",
}

KOTLIN_PREFIX_TEMPLATE_FAMILIES: "OrderedDict[str, str]" = OrderedDict([
    ("parsepayload", "Kotlin::numeric_parse"),
    ("updatecounter", "Kotlin::shared_counter"),
    ("handleinput", "Kotlin::input_gate"),
    ("fetchsecure", "Kotlin::wire_mapping"),
])


def _looks_like_kotlin_sample(sample: "Sample", normalized_name: str = "") -> bool:
    label = str(sample.dataset_label or "").strip()
    if label in KOTLIN_DATASET_LABELS or str(sample.source_label or "").strip() in KOTLIN_DATASET_LABELS:
        return True
    name = normalized_name or _normalize_proc_name_for_family(sample.proc_name)
    lname = name.lower()
    if lname.startswith(tuple(KOTLIN_PREFIX_TEMPLATE_FAMILIES.keys())):
        return True
    code = str(sample.code or "")
    kotlin_markers = [
        "fun ",
        "val ",
        "mutableMapOf",
        "toIntOrNull()",
        "lowercase()",
        "data class ",
        "MutableList<String>",
    ]
    return any(marker in code for marker in kotlin_markers)


def _normalize_kotlin_code_for_family(code: str) -> str:
    text = normalize_code_for_group(code).lower()
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.DOTALL)
    text = re.sub(r"//.*", " ", text)
    text = re.sub(r'"([^"\\]|\\.)*"', "STR", text)
    text = re.sub(r"'([^'\\]|\\.)*'", "CHR", text)
    text = re.sub(r"\bcase_\d+\b", "case_fn", text)
    text = re.sub(r"\bcounterbox\d+\b", "counter_box", text)
    text = re.sub(r"\bpayload\d+\b", "payload_type", text)
    text = re.sub(r"\block\d+\b", "sync_lock", text)
    text = re.sub(r"\b\d+\b", "N", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def infer_kotlin_template_family(sample: "Sample") -> Optional[str]:
    if sample.pair_group:
        return f"Kotlin::pair::{sample.pair_group}"

    proc_name = _normalize_proc_name_for_family(sample.proc_name)
    lname = _strip_safe_suffix(proc_name).lower()
    dataset_label = str(sample.dataset_label or "").strip()
    source_label = str(sample.source_label or "").strip()
    code = _normalize_kotlin_code_for_family(sample.code)

    if "thread.sleep(" in code and "mutablemapof<string, int>()" in code:
        return "Kotlin::shared_counter"
    if ".toint()" in code or ".tointornull()" in code:
        return "Kotlin::numeric_parse"
    if "ignorecase = true" in code or ".lowercase()" in code:
        return "Kotlin::case_compare"
    if "regex(" in code or 'contains(STR)' in code or 'audit.add("rejected")' in sample.code or '$basedir/$cleaned' in sample.code.lower():
        if dataset_label == "Improper_Handling_Of_Case_Sensitivity" or source_label == "Improper_Handling_Of_Case_Sensitivity":
            return "Kotlin::case_compare"
        if dataset_label == "Improper_Input_Validation" or source_label == "Improper_Input_Validation":
            return "Kotlin::input_gate"
    if "mutablemapof(" in code or 'return "{' in sample.code or ("listof(" in code and " to " in code):
        return "Kotlin::wire_mapping"

    if lname.startswith("parsepayload"):
        return "Kotlin::numeric_parse"
    if lname.startswith("updatecounter"):
        return "Kotlin::shared_counter"
    if lname.startswith("handleinput"):
        if dataset_label == "Improper_Handling_Of_Case_Sensitivity" or source_label == "Improper_Handling_Of_Case_Sensitivity":
            return "Kotlin::case_compare"
        return "Kotlin::input_gate"
    if lname.startswith("fetchsecure"):
        return "Kotlin::wire_mapping"

    for prefix, family in KOTLIN_PREFIX_TEMPLATE_FAMILIES.items():
        if lname.startswith(prefix):
            return family

    return None



def _looks_like_rust_sample(sample: "Sample", normalized_name: str = "") -> bool:
    label = str(sample.dataset_label or "").strip()
    if label in RUST_DATASET_LABELS or str(sample.source_label or "").strip() in RUST_DATASET_LABELS:
        return True
    name = normalized_name or _normalize_proc_name_for_family(sample.proc_name)
    lname = name.lower()
    if "_rustsec_" in lname:
        return True
    code = str(sample.code or "")
    rust_markers = ["pub fn ", "use std::", "Vec::", "String::", "std::process::Command", "unsafe {"]
    return any(marker in code for marker in rust_markers)


def _normalize_rust_code_for_family(code: str) -> str:
    text = normalize_code_for_group(code).lower()
    text = re.sub(r"/\*.*?\*/", " ", text, flags=re.DOTALL)
    text = re.sub(r"//.*", " ", text)
    text = re.sub(r'"([^"\\]|\\.)*"', "STR", text)
    text = re.sub(r"'([^'\\]|\\.)*'", "CHR", text)
    text = re.sub(r"\bcase_\d+\b", "case_fn", text)
    text = re.sub(r"\b[a-z_][a-z0-9_]*_rustsec_\d{4}_\d{4}\b", "rustsec_fn", text)
    text = re.sub(r"\bstate_\d+\b", "state_id", text)
    text = re.sub(r"\bglobal_count_rustsec_\d{4}_\d{4}\b", "global_counter", text)
    text = re.sub(r"\b\d+\b", "N", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def infer_rust_template_family(sample: "Sample") -> Optional[str]:
    if sample.pair_group:
        return f"Rust::pair::{sample.pair_group}"

    proc_name = _normalize_proc_name_for_family(sample.proc_name)
    lname = _strip_safe_suffix(proc_name).lower()
    code = _normalize_rust_code_for_family(sample.code)

    # code-first grouping: keep vulnerable/safe near-duplicates in the same family
    if ("unsafe {" in code or "unsafe{" in code) and ".as_ptr()" in code and ".add(" in code:
        return "Rust::unsafe_buffer_offset"
    if "vec::with_capacity" in code and ".resize(" in code:
        return "Rust::bounded_allocation"
    if "command::new" in code and ".arg(" in code and ".output()?" in code:
        return "Rust::process_command"
    if "from_utf8_lossy" in code and "extend_from_slice" in code:
        return "Rust::buffer_to_string"
    if 'replace(STR, value' in code or ("replace(" in code and "{value}" in sample.code and "{debug}" in sample.code):
        return "Rust::template_rewrite"
    if "contains(" in code or "matches!(" in code:
        if "-> bool" in code or " bool {" in code:
            return "Rust::authorization_check"
    if "static mut" in code or "atomicusize" in code or "fetch_add(" in code:
        return "Rust::shared_counter"
    if "pbkdf2" in code or "as_bytes().iter().enumerate().take(" in code or "^ 0x" in code:
        return "Rust::fixed_bytes_derivation"

    # name fallback for older rustsec-style datasets
    if "_rustsec_" in lname:
        for prefix, family in RUST_PREFIX_TEMPLATE_FAMILIES.items():
            if lname.startswith(prefix):
                return family

    # soft code-shape fallbacks for cleaned datasets
    if "-> [u8;" in sample.code and "&str" in sample.code:
        return "Rust::fixed_bytes_derivation"
    if "-> std::io::result<string>" in code and "sh" in code:
        return "Rust::process_command"
    if "-> string" in code and "from_utf8_lossy" in code:
        return "Rust::buffer_to_string"
    if "-> vec<u8>" in code and "with_capacity" in code:
        return "Rust::bounded_allocation"
    return None


def _normalize_proc_name_for_family(proc_name: str) -> str:
    name = str(proc_name or "").strip()
    name = re.sub(r"^s\d+__", "", name, flags=re.IGNORECASE)
    return name


def _strip_safe_suffix(name: str) -> str:
    base = str(name or "").strip()
    base = re.sub(r"_safe$", "", base, flags=re.IGNORECASE)
    base = re.sub(r"safe$", "", base, flags=re.IGNORECASE)
    return base


def infer_template_family(sample: "Sample") -> str:
    explicit_family = str(getattr(sample, "template_family", "") or "").strip()
    if explicit_family:
        return explicit_family

    proc_name = _normalize_proc_name_for_family(sample.proc_name)
    name = proc_name.strip()
    dataset_label = str(sample.dataset_label or "").strip()

    if _looks_like_kotlin_sample(sample, normalized_name=name):
        kotlin_family = infer_kotlin_template_family(sample)
        if kotlin_family:
            return kotlin_family

    if _looks_like_rust_sample(sample, normalized_name=name):
        rust_family = infer_rust_template_family(sample)
        if rust_family:
            return rust_family

    # generic fallback: keep Nim and any other non-Rust / non-Kotlin datasets working
    base = _strip_safe_suffix(name)
    fallback = base.lower().replace("?", "")
    fallback = re.sub(r"\d+$", "", fallback)
    if "." in fallback:
        cls, meth = fallback.split(".", 1)
        cls = re.sub(r"safe", "", cls)
        cls = re.sub(r"\d+$", "", cls)
        meth = re.sub(r"\d+$", "", meth)
        fallback = f"{cls}.{meth}"
    if not fallback:
        fallback = "unknown_template"
    prefix = dataset_label if dataset_label else "UnknownLabel"
    return f"{prefix}::{fallback}"


def choose_group_id(sample: "Sample", group_mode: str = "code_hash") -> Tuple[str, str, str]:
    code_group_id = make_code_group_id(sample.code)
    template_family_id = infer_template_family(sample)

    if group_mode == "code_hash":
        chosen = code_group_id
    elif group_mode == "template_family":
        chosen = template_family_id
    elif group_mode == "template_then_hash":
        chosen = f"{template_family_id}::{code_group_id}"
    else:
        raise ValueError(f"未知 group_mode: {group_mode}")

    return chosen, code_group_id, template_family_id
def normalize_label_token(value: Any) -> Any:
    if value is None:
        return None
    if isinstance(value, (int, np.integer)):
        return int(value)
    text = str(value).strip()
    if text == "":
        return ""
    if re.fullmatch(r"[-+]?\d+", text):
        return int(text)
    return text


def load_labels(labels_json: str | None) -> Dict[str, Any]:
    if not labels_json:
        return DEFAULT_LABELS.copy()

    with open(labels_json, "r", encoding="utf-8") as f:
        labels_obj = json.load(f)

    if isinstance(labels_obj, dict):
        # 支持两种格式：
        # 1) 纯 sample_id -> label 的扁平 dict
        # 2) 带摘要信息的 bundle，例如：
        #    {"label_to_id": {...}, "id_to_label": {...}, "labels_by_sample_id": {...}}
        if "labels_by_sample_id" in labels_obj and isinstance(labels_obj["labels_by_sample_id"], dict):
            raw_map = labels_obj["labels_by_sample_id"]
            id_to_label = {
                str(k): str(v)
                for k, v in (labels_obj.get("id_to_label") or {}).items()
            }
            if id_to_label:
                converted: Dict[str, Any] = {}
                for k, v in raw_map.items():
                    token = normalize_label_token(v)
                    if isinstance(token, int) and str(token) in id_to_label:
                        converted[str(k)] = id_to_label[str(token)]
                    else:
                        converted[str(k)] = normalize_label_token(v)
                return converted
            return {
                str(k): normalize_label_token(v)
                for k, v in raw_map.items()
            }
        return {str(k): normalize_label_token(v) for k, v in labels_obj.items()}

    if isinstance(labels_obj, list):
        labels: Dict[str, Any] = {}
        for item in labels_obj:
            if not isinstance(item, dict):
                continue
            key = (
                item.get("sample_id")
                or item.get("sample_key")
                or item.get("proc_name")
                or item.get("name")
            )
            value = item.get("dataset_label", item.get("binary_label", item.get("label")))
            if key is None or value is None:
                continue
            labels[str(key)] = normalize_label_token(value)
        return labels

    raise ValueError("labels_json 必须是 dict、bundle dict 或 list[dict] 结构。")


def load_label_order(labels_json: str | None) -> Dict[str, int]:
    if not labels_json:
        return {}

    with open(labels_json, "r", encoding="utf-8") as f:
        labels_obj = json.load(f)

    if not isinstance(labels_obj, dict):
        return {}

    raw_label_to_id = labels_obj.get("label_to_id")
    if isinstance(raw_label_to_id, dict):
        ordered: List[Tuple[str, int]] = []
        for name, value in raw_label_to_id.items():
            token = normalize_label_token(value)
            if isinstance(token, int):
                ordered.append((str(name).strip(), int(token)))
        if ordered:
            ordered.sort(key=lambda kv: kv[1])
            return OrderedDict((name, idx) for name, idx in ordered if name)

    raw_id_to_label = labels_obj.get("id_to_label")
    if isinstance(raw_id_to_label, dict):
        ordered = []
        for idx, name in raw_id_to_label.items():
            token = normalize_label_token(idx)
            if isinstance(token, int):
                ordered.append((int(token), str(name).strip()))
        if ordered:
            ordered.sort(key=lambda kv: kv[0])
            return OrderedDict((name, idx) for idx, name in ordered if name)

    return {}


def infer_dataset_label_to_id(
    raw: List[Dict[str, Any]],
    preferred_label_to_id: Optional[Dict[str, int]] = None,
) -> Dict[str, int]:
    dataset_labels = {
        str(item.get("dataset_label", "")).strip()
        for item in raw
        if str(item.get("dataset_label", "")).strip()
    }

    if preferred_label_to_id:
        inferred: "OrderedDict[str, int]" = OrderedDict()
        used_ids = set()
        for name, idx in sorted(preferred_label_to_id.items(), key=lambda kv: kv[1]):
            if name in dataset_labels:
                inferred[name] = int(idx)
                used_ids.add(int(idx))

        extras = sorted(
            [name for name in dataset_labels if name not in inferred],
            key=lambda x: (x != "Safe", x),
        )
        next_id = 0
        while next_id in used_ids:
            next_id += 1
        for name in extras:
            while next_id in used_ids:
                next_id += 1
            inferred[name] = next_id
            used_ids.add(next_id)
            next_id += 1
        if inferred:
            return dict(inferred)

    labels = sorted(dataset_labels, key=lambda x: (x != "Safe", x))
    return {name: idx for idx, name in enumerate(labels)}


def coerce_label_to_id(value: Any, dataset_label_to_id: Optional[Dict[str, int]]) -> Optional[int]:
    token = normalize_label_token(value)
    if token is None or token == "":
        return None
    if isinstance(token, int):
        return int(token)
    if dataset_label_to_id and token in dataset_label_to_id:
        return int(dataset_label_to_id[token])
    return None


def derive_label_space_from_samples(samples: List[Sample]) -> Tuple[Dict[str, int], Dict[int, str], List[str]]:
    name_to_id: Dict[str, int] = {}
    for sample in samples:
        label_name = str(sample.dataset_label or "").strip()
        if not label_name:
            continue
        if label_name in name_to_id and name_to_id[label_name] != int(sample.label):
            raise ValueError(f"标签映射冲突: {label_name} -> {name_to_id[label_name]} vs {sample.label}")
        name_to_id[label_name] = int(sample.label)

    if name_to_id:
        id_to_label = {idx: name for name, idx in name_to_id.items()}
    else:
        uniq_ids = sorted({int(sample.label) for sample in samples if int(sample.label) >= 0})
        id_to_label = {idx: str(idx) for idx in uniq_ids}
        name_to_id = {name: idx for idx, name in id_to_label.items()}

    label_names = [id_to_label[idx] for idx in sorted(id_to_label)]
    return name_to_id, id_to_label, label_names


SKELETON_FIELD_CANDIDATES = ("key_skeleton", "skeleton", "anchor_skeleton")


def resolve_sample_id(item: Dict[str, Any], index: int) -> str:
    if item.get("sample_id"):
        return str(item["sample_id"])
    if item.get("sample_key"):
        return str(item["sample_key"])
    proc_name = str(item.get("proc_name", f"sample_{index + 1}"))
    snippet_no = item.get("snippet_no")
    if snippet_no is not None:
        return f"s{int(snippet_no):04d}__{proc_name}"
    return proc_name


def select_skeleton_value(item: Dict[str, Any], skeleton_field: str = "auto") -> Tuple[str, str]:
    if skeleton_field != "auto":
        value = str(item.get(skeleton_field, "") or "").strip()
        if not value:
            raise ValueError(f"样本 {item.get('proc_name', '<unknown>')} 缺少骨架字段 {skeleton_field}")
        return value, skeleton_field

    for field in SKELETON_FIELD_CANDIDATES:
        value = str(item.get(field, "") or "").strip()
        if value:
            return value, field
    raise ValueError(
        f"样本 {item.get('proc_name', '<unknown>')} 缺少可用骨架字段。"
        f"请提供 {SKELETON_FIELD_CANDIDATES} 之一。"
    )


def resolve_label_for_item(
    item: Dict[str, Any],
    labels_map: Dict[str, Any],
    sample_id: str,
    proc_name: str,
    require_label: bool,
    default_label: int,
    dataset_label_to_id: Optional[Dict[str, int]] = None,
) -> int:
    key_candidates = [sample_id, proc_name]
    if item.get("snippet_no") is not None:
        key_candidates.append(str(item["snippet_no"]))

    for key in key_candidates:
        if key in labels_map:
            coerced = coerce_label_to_id(labels_map[key], dataset_label_to_id)
            if coerced is not None:
                return int(coerced)

    if item.get("dataset_label") is not None:
        coerced = coerce_label_to_id(item.get("dataset_label"), dataset_label_to_id)
        if coerced is not None:
            return int(coerced)

    if item.get("binary_label") is not None:
        return int(item["binary_label"])

    if require_label:
        raise ValueError(
            f"样本 {sample_id} / {proc_name} 没有标签。请在 labels_json 中补齐，"
            "或确保输入 JSON 自带 dataset_label / binary_label。"
        )
    return int(default_label)

def load_samples(
    input_json: str,
    labels_map: Optional[Dict[str, Any]] = None,
    require_label: bool = True,
    default_label: int = -1,
    skeleton_field: str = "auto",
    dataset_label_to_id: Optional[Dict[str, int]] = None,
) -> List[Sample]:
    with open(input_json, "r", encoding="utf-8") as f:
        raw = json.load(f)

    if not isinstance(raw, list):
        raise ValueError("输入 JSON 顶层必须是 list。")

    samples: List[Sample] = []
    labels_map = labels_map or {}
    inferred_label_to_id = dataset_label_to_id or infer_dataset_label_to_id(raw)

    for idx, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError(f"第 {idx} 条样本不是对象结构。")

        proc_name = str(item.get("proc_name", f"sample_{idx + 1}"))
        sample_id = resolve_sample_id(item, idx)
        label = resolve_label_for_item(
            item=item,
            labels_map=labels_map,
            sample_id=sample_id,
            proc_name=proc_name,
            require_label=require_label,
            default_label=default_label,
            dataset_label_to_id=inferred_label_to_id,
        )
        skeleton_value, skeleton_field_used = select_skeleton_value(item, skeleton_field=skeleton_field)

        samples.append(
            Sample(
                sample_id=sample_id,
                proc_name=proc_name,
                code=str(item.get("code", "")),
                nodes=list(item.get("nodes", [])),
                skeleton=skeleton_value,
                label=label,
                notes=str(item.get("notes", "")),
                dataset_label=str(item.get("dataset_label", "")),
                binary_label=int(item["binary_label"]) if item.get("binary_label") is not None else None,
                skeleton_field_used=skeleton_field_used,
                pair_group=str(item.get("pair_group", "") or ""),
                pair_role=str(item.get("pair_role", "") or ""),
                source_label=str(item.get("source_label", "") or ""),
                template_family=str(item.get("template_family", "") or ""),
                language=str(item.get("language", "") or ""),
            )
        )
    return samples

def key_node_family(name: str) -> str:
    base = str(name or "").strip()
    if not base:
        return "UNKNOWN"
    match = re.match(r"([A-Za-z_][A-Za-z0-9_]*)", base)
    return match.group(1) if match else base


def _simple_type_name(type_text: str) -> str:
    text = str(type_text or "").strip()
    if not text:
        return "UNKNOWN"
    text = re.sub(r"\s+", "", text)
    low = text.lower()
    if low in {"string", "cstring", "seq[string]"}:
        return "string"
    if low in {"int", "int32", "int64", "uint", "uint32", "uint64", "float", "float32", "float64"}:
        return "number"
    if low in {"bool", "boolean"}:
        return "bool"
    if "json" in low:
        return "json"
    if low.startswith("seq[") or low.startswith("array[") or low.startswith("openarray["):
        return "collection"
    return re.sub(r"[^A-Za-z0-9_]+", "_", text)[:32] or "UNKNOWN"


def _safe_payload_token(value: str, max_len: int = 48) -> str:
    token = re.sub(r"[^A-Za-z0-9_]+", "_", str(value or "").strip())
    token = re.sub(r"_+", "_", token).strip("_")
    return (token[:max_len] or "VALUE")


def _operation_bucket(payload: str) -> str:
    low = str(payload or "").strip().lower()
    safe = _safe_payload_token(low).upper()
    if any(x in low for x in ["effect_text", "effect_process", "effect_local", "effect_memory"]):
        return f"EFFECT_{safe}"
    if any(x in low for x in ["mode_a", "mode_b", "mode_c", "pattern_a", "pattern_b", "pattern_c", "region_a", "region_b"]):
        return f"MODE_{safe}"
    if any(x in low for x in ["overread", "mem_read_over", "read_beyond", "upper_read"]):
        return f"MEM_READ_OVER_{safe}"
    if any(x in low for x in ["underread", "mem_read_under", "read_before", "lower_read"]):
        return f"MEM_READ_UNDER_{safe}"
    if any(x in low for x in ["printf", "fprintf", "snprintf", "vprintf", "syslog", "format"]):
        return f"FORMAT_{safe}"
    if any(x in low for x in ["system", "execl", "execv", "execvp", "spawn", "popen", "command"]):
        return f"CMD_{safe}"
    if any(x in low for x in ["malloc", "calloc", "realloc", "heap"]):
        return f"ALLOC_HEAP_{safe}"
    if any(x in low for x in ["alloca", "stack"]):
        return f"ALLOC_STACK_{safe}"
    if any(x in low for x in ["memcpy", "memmove", "strcpy", "strncpy", "snprintf", "ncat", "cat", "copy", "write"]):
        loc = "HEAP" if "heap" in low or "malloc" in low else ("STACK" if "stack" in low or "alloca" in low else "BUFFER")
        return f"MEM_WRITE_{loc}_{safe}"
    if any(x in low for x in ["postinc", "preinc", "increment", "add", "overflow", "upper"]):
        return f"ARITH_INC_UPPER_{safe}"
    if any(x in low for x in ["postdec", "predec", "decrement", "sub", "underflow", "lower"]):
        return f"ARITH_DEC_LOWER_{safe}"
    if any(x in low for x in ["sanitize", "validate", "allowlist", "bound", "check", "safe"]):
        return f"GUARD_{safe}"
    return safe


def normalize_key_node_token(name: str) -> str:
    """Normalize raw key_node strings for RQ3-v2.

    The original feature kept exact variable names, function names, URLs and
    business endpoints, e.g. Parameter(packageName:string) or
    ConcatExpr("https://..."&packageName). In few-shot MAML these sparse
    tokens can behave as template noise. This function keeps the structural
    operation and coarse semantic role while hiding unstable identifiers.
    """
    s = str(name or "").strip()
    if not s:
        return "UNKNOWN"
    head = key_node_family(s)

    m = re.match(r"Parameter\([^:()]+:([^()]+)\)", s)
    if m:
        return f"Parameter({_simple_type_name(m.group(1))})"

    if head in {"Assignment", "FieldAssignment", "VarDeclaration", "LetDeclaration", "IndexedAssignment"}:
        return f"{head}(VAR)"

    if head in {"TupleDeconstruct", "ObjectConstruction"}:
        return head

    if head in {"ReturnField", "FieldReturn"}:
        return "ReturnField(VAR.FIELD)"
    if head == "ReturnExpr":
        return "ReturnExpr(EXPR)"
    if head in {"ReturnValue", "ReturnCollection"}:
        return f"{head}(CONST)"
    if head == "ReturnCall":
        return "ReturnCall(FUNC)"

    m = re.match(r"(Expr|InfixExpr|ConcatExpr|StringInterpolation)\((.*)\)$", s)
    if m:
        bucket = _operation_bucket(m.group(2))
        if bucket.startswith(("ARITH_", "MEM_READ_", "FORMAT_", "CMD_", "EFFECT_", "MODE_")):
            return f"{m.group(1)}({bucket})"
        return f"{m.group(1)}(EXPR)"

    m = re.match(r"(Guard|IfCondition|ElifCondition|CaseCondition)\((.*)\)$", s)
    if m:
        bucket = _operation_bucket(m.group(2))
        if bucket.startswith(("GUARD_", "ARITH_", "MEM_READ_")):
            return f"{m.group(1)}({bucket})"
        return f"{m.group(1)}(CHECK)"

    if head in {"TryBlock", "ExceptBlock", "FinallyBlock", "ElseBranch", "ForLoop", "WhileLoop", "CaseBlock", "Break", "Continue", "Raise"}:
        return head

    m = re.match(r"Call\(([^()]+)\)", s)
    if m:
        bucket = _operation_bucket(m.group(1))
        if bucket.startswith(("FORMAT_", "CMD_", "MEM_WRITE_", "MEM_READ_", "ALLOC_", "GUARD_", "EFFECT_", "MODE_")):
            return f"Call({bucket})"
        callee = m.group(1).strip().lower()
        if any(x in callee for x in ["exec", "system", "startprocess", "command", "run", "shell", "nimble"]):
            return "Call(COMMAND_EXEC)"
        if "close" in callee:
            return "Call(RESOURCE_CLOSE)"
        if any(x in callee for x in ["new", "init"]):
            return "Call(INIT_RESOURCE)"
        if any(x in callee for x in ["parsejson", "parsexml", "decode", "readexactly", "contentlength", "response"]):
            return "Call(PARSE_RESPONSE)"
        if any(x in callee for x in ["sanitize", "escape", "validate", "normalize", "canonical", "clean", "check", "whitelist", "startswith"]):
            return "Call(SAFE_GUARD)"
        if any(x in callee for x in ["writefile", "readfile", "open", "extract", "unzip", "zip", "include", "load", "removefile", "copyfile"]):
            return "Call(FILE_OP)"
        if any(x in callee for x in ["render", "html", "rst", "markdown", "markup", "template"]):
            return "Call(RENDER)"
        if any(x in callee for x in [".get", ".post", ".put", ".delete", ".patch", "request", "xmlrpc", "soap", "graphql", "websocket"]):
            return "Call(NETWORK_REQUEST)"
        return "Call(FUNC)"

    return head


def extract_cross_language_key_semantics(raw_tokens: Sequence[str], normalized_tokens: Sequence[str]) -> List[str]:
    """Add language-agnostic semantic buckets so weak per-language key vocabularies
    still expose stable security concepts across Rust/Nim/C/Java/Python."""
    joined = " || ".join([str(x or "") for x in raw_tokens] + [str(x or "") for x in normalized_tokens]).lower()
    buckets: List[str] = []

    def has_any(words: Sequence[str]) -> bool:
        return any(word in joined for word in words)

    if has_any(["unsafe", "rawpointer", "as_ptr", ".add(", "offset", "pointer", "ptr"]):
        buckets.append("KS:MEMORY_ACCESS")
    if has_any(["vec::with_capacity", "resize", "allocation", "malloc", "calloc", "realloc", "buffer"]):
        buckets.append("KS:MEMORY_ALLOCATION")
    if has_any(["command", "exec", "system", "shell", "process", "startprocess", "command::new", ".output("]):
        buckets.append("KS:COMMAND_EXEC")
    if has_any(["request", "network", "socket", "xmlrpc", "soap", "graphql", "websocket", "http", "url"]):
        buckets.append("KS:NETWORK_IO")
    if has_any(["open", "readfile", "writefile", "include", "path", "directory", "archive", "zip", "extract", "file_op"]):
        buckets.append("KS:FILE_PATH_IO")
    if has_any(["render", "template", "markup", "html", "markdown", "rst", "format", "replace("]):
        buckets.append("KS:RENDER_FORMAT")
    if has_any(["validate", "sanitize", "escape", "canonical", "normalize", "check", "guard", "startswith"]):
        buckets.append("KS:VALIDATION_GUARD")
    if has_any(["auth", "authorize", "permission", "privilege", "access", "contains(", "matches!("]):
        buckets.append("KS:AUTHORIZATION")
    if has_any(["atomic", "mutex", "lock", "thread", "shared", "fetch_add", "static mut", "counter"]):
        buckets.append("KS:CONCURRENCY_STATE")
    if has_any(["json", "xml", "serialize", "deserialize", "parse", "decode", "from_utf8", "response"]):
        buckets.append("KS:PARSE_SERIALIZE")
    return buckets


def anchor_family(name: str) -> str:
    base = str(name or "").strip()
    if not base:
        return "UNKNOWN"
    base = base.split("(", 1)[0].strip()
    return base if base else "UNKNOWN"


def normalize_anchor_token(name: str) -> str:
    """Coarsen anchor payloads while preserving security semantics.

    Raw anchors often contain variable/function names such as
    DataBinding(Command) or FileIncludeSink(includeFile1). Keeping every raw
    payload makes the anchor module dominate RQ3. This keeps the anchor family
    and a small set of semantic payload buckets, but removes unstable names.
    """
    s = str(name or "").strip()
    if not s:
        return "UNKNOWN"
    fam = anchor_family(s)
    m = re.match(r"^[^(]+\((.*)\)$", s)
    payload = m.group(1).strip() if m else ""
    low = payload.lower()

    if not payload:
        return fam

    if fam in {"InputKind", "FlowDomain", "CheckState", "UseKind", "StorageKind", "AccessPattern"}:
        return f"{fam}({_safe_payload_token(payload).upper()})"

    if fam in {"FormatSink", "CommandSink"}:
        return "ExternalSink(USE)"
    if fam == "NumericOperation":
        return "NumericOperation(ARITH)"
    if fam in {"BoundaryCheck", "Check", "Sanitization", "Validation"}:
        return f"{fam}(CHECK)"
    if fam in {"MemoryRead", "MemoryWrite", "Access"}:
        return "MemoryAccess(ACCESS)"
    if fam == "Allocation":
        return "Allocation(BUFFER)"
    if fam in {"BufferObject", "Object"}:
        return "BufferObject(BUFFER)"
    if fam == "InputSource":
        return "InputSource(INPUT)"
    if fam == "Transform":
        return "Transform(BUILD)"
    if fam in {"Use", "SafeUse"}:
        return "Use(USE)"

    if fam == "DataBinding":
        if any(x in low for x in ["command", "cmd", "exec", "shell", "process"]):
            return "DataBinding(COMMAND)"
        if any(x in low for x in ["url", "uri", "endpoint", "host"]):
            return "DataBinding(URL)"
        if any(x in low for x in ["path", "file", "filename", "directory", "dir"]):
            return "DataBinding(PATH)"
        if any(x in low for x in ["header", "cookie", "connection", "te", "referer", "expect", "forwarded"]):
            return "DataBinding(HEADER)"
        if any(x in low for x in ["body", "content", "html", "rst", "markdown", "template"]):
            return "DataBinding(CONTENT)"
        if any(x in low for x in ["response", "json", "xml"]):
            return "DataBinding(RESPONSE)"
        return "DataBinding(VALUE)"

    if fam in {"CommandConstruction", "DangerousCommandExecution", "ProcessInvocation", "ProcessWait"}:
        return f"{fam}(COMMAND)"
    if fam in {"FileIncludeSink", "FileRead", "FileWrite", "PathConstruction", "ArchiveExtraction"}:
        return f"{fam}(FILE)"
    if fam in {"NetworkRequest", "URLConstruction", "PayloadConstruction"}:
        return f"{fam}(NETWORK)"
    if fam in {"MarkupRendering", "UnsafeMarkupRendering", "SafeMarkupRendering"}:
        return f"{fam}(MARKUP)"
    if fam in {"ValidationCheck", "ValidationFailureAbort", "SecurityEnforcement", "Sanitization"}:
        return f"{fam}(GUARD)"
    if fam in {"ResponseParsing", "ResponseHeaderRead", "ContentLengthRead"}:
        return f"{fam}(RESPONSE)"
    if fam in {"ValueReturn", "BooleanReturn", "FieldReturn"}:
        return f"{fam}(RETURN)"
    if fam in {"ResourceInitialization", "ResourceCleanup", "LocalStateDeclaration", "FieldWrite", "IndexedWrite"}:
        return fam

    return fam


def extract_key_nodes(sample: Sample) -> List[str]:
    return [str(node["key_node"]).strip() for node in sample.nodes if "key_node" in node]


def is_core_key_node_feature(name: str) -> bool:
    """Keep only security-relevant / structure-relevant key-node features.

    RQ3-v2-corekey first-version change:
    - Only the key-node vector is filtered.
    - Anchor features and skeleton bigrams are deliberately left unchanged,
      so we can isolate whether ordinary key nodes were dragging down Full.
    """
    s = str(name or "").strip()
    if not s:
        return False

    # Family features are generated only after filtering core normalized tokens,
    # but keep this guard for older configs / loaded vocabs.
    if s.startswith("KF:"):
        fam = s[3:]
        return fam in {
            "Parameter",
            "Assignment",
            "FieldAssignment",
            "VarDeclaration",
            "LetDeclaration",
            "IndexedAssignment",
            "ConcatExpr",
            "InfixExpr",
            "StringInterpolation",
            "Expr",
            "Guard",
            "IfCondition",
            "ElifCondition",
            "CaseCondition",
            "ForLoop",
            "WhileLoop",
            "TryBlock",
            "ExceptBlock",
            "FinallyBlock",
            "ElseBranch",
            "CaseBlock",
            "ReturnField",
            "ReturnExpr",
            "ReturnValue",
            "ReturnCall",
            "Call",
        }

    # External input / argument entry points.
    if s.startswith("Parameter("):
        return True

    if s.startswith(("Assignment(", "FieldAssignment(", "VarDeclaration(", "LetDeclaration(", "IndexedAssignment(")):
        return True

    if s.startswith(("Expr(", "Guard(")):
        return True

    # Construction expressions are important for command/path/header/url/html building.
    if s.startswith(("ConcatExpr", "InfixExpr", "StringInterpolation")):
        return True

    # Control-flow and recovery nodes can distinguish checks from sinks.
    if s.startswith((
        "IfCondition",
        "ElifCondition",
        "CaseCondition",
        "ForLoop",
        "WhileLoop",
        "TryBlock",
        "ExceptBlock",
        "FinallyBlock",
        "ElseBranch",
        "CaseBlock",
    )):
        return True

    # Keep only semantically important coarse call types after normalization.
    # Drop common noise such as Call(INIT_RESOURCE), Call(RESOURCE_CLOSE),
    # Call(PARSE_RESPONSE), and Call(FUNC).
    if s.startswith("Call("):
        return s in {
            "Call(COMMAND_EXEC)",
            "Call(FILE_OP)",
            "Call(RENDER)",
            "Call(SAFE_GUARD)",
            "Call(NETWORK_REQUEST)",
            "Call(PARSE_RESPONSE)",
            "Call(INIT_RESOURCE)",
            "Call(RESOURCE_CLOSE)",
        } or s.startswith(("Call(FORMAT_", "Call(CMD_", "Call(MEM_WRITE_", "Call(MEM_READ_", "Call(ALLOC_", "Call(GUARD_", "Call(EFFECT_", "Call(MODE_"))

    # ReturnField can still be useful for response/body/header-style flows.
    # Plain ReturnValue/ReturnCollection/ReturnCall(FUNC) are treated as ordinary.
    if s.startswith("ReturnField("):
        return True

    if s.startswith(("ReturnExpr(", "ReturnValue(", "ReturnCall(")):
        return True

    return False


def extract_key_node_features(sample: Sample) -> List[str]:
    raw = extract_key_nodes(sample)
    normalized = [normalize_key_node_token(name) for name in raw]

    # First-version ordinary-key-node filtering: affect key_vec only.
    # Skeleton tokens are not filtered here; anchors are not changed.
    core_tokens = [name for name in normalized if is_core_key_node_feature(name)]

    # Family features should describe retained core nodes only. Otherwise, a broad
    # KF:Call or KF:Assignment from ordinary calls/assignments would reintroduce noise.
    families = [
        f"KF:{key_node_family(name)}"
        for name in core_tokens
        if is_core_key_node_feature(f"KF:{key_node_family(name)}")
    ]
    semantics = extract_cross_language_key_semantics(raw, core_tokens)
    return core_tokens + families + semantics


def extract_anchors(sample: Sample) -> List[str]:
    anchors = []
    for node in sample.nodes:
        anchor = node.get("anchor", "")
        if anchor is None:
            continue
        anchor = str(anchor).strip()
        if anchor:
            anchors.append(anchor)
    return anchors


def extract_anchor_features(sample: Sample) -> List[str]:
    raw = extract_anchors(sample)
    normalized = [normalize_anchor_token(name) for name in raw]
    families = [f"AF:{anchor_family(name)}" for name in normalized]
    return normalized + families


def parse_skeleton(skeleton: str) -> List[str]:
    if not skeleton:
        return []
    return [part.strip() for part in skeleton.split("→") if part.strip()]


def normalize_skeleton_token(token: str) -> str:
    token = str(token).strip()
    if not token:
        return ""
    token = re.sub(r"\s+", " ", token)
    token = re.sub(r"\s*→\s*", "→", token)

    # When using key_skeleton, normalize each structural token with the same
    # abstraction as key nodes. Anchor-skeleton tokens such as InputSource or
    # NetworkRequest(GET) do not match these key-node heads and are left coarse.
    if re.match(r"^(Parameter|Assignment|FieldAssignment|VarDeclaration|LetDeclaration|ReturnField|FieldReturn|ReturnValue|ReturnCollection|ReturnCall|ConcatExpr|InfixExpr|StringInterpolation|IfCondition|ElifCondition|CaseCondition|TryBlock|ExceptBlock|FinallyBlock|ElseBranch|ForLoop|WhileLoop|CaseBlock|Call)\b", token):
        return normalize_key_node_token(token)
    return token.strip()

def extract_normalized_skeleton_tokens(sample: Sample) -> List[str]:
    return [normalize_skeleton_token(tok) for tok in parse_skeleton(sample.skeleton)]


def skeleton_to_bigrams(tokens: List[str]) -> List[str]:
    if len(tokens) < 2:
        return []
    return [f"{tokens[i]}->{tokens[i + 1]}" for i in range(len(tokens) - 1)]


def build_vocab(items: Sequence[str]) -> Dict[str, int]:
    uniq = sorted(set(items))
    return {name: idx for idx, name in enumerate(uniq)}


def build_vocab_with_min_freq(items: Sequence[str], min_freq: int = 1) -> Dict[str, int]:
    if min_freq <= 1:
        return build_vocab(items)
    counter = Counter(items)
    uniq = sorted([name for name, count in counter.items() if count >= min_freq])
    return {name: idx for idx, name in enumerate(uniq)}


def build_key_node_vocab(samples: List[Sample]) -> Dict[str, int]:
    items: List[str] = []
    for sample in samples:
        items.extend(extract_key_node_features(sample))
    # v3: after structural normalization, keep rare-but-security-relevant key
    # nodes; otherwise the key module becomes too weak in the full model.
    return build_vocab_with_min_freq(items, min_freq=1)


def build_anchor_vocab(samples: List[Sample]) -> Dict[str, int]:
    items: List[str] = []
    for sample in samples:
        items.extend(extract_anchor_features(sample))
    return build_vocab(items)


def skeleton_to_features(tokens: List[str]) -> List[str]:
    features = [f"SU:{tok}" for tok in tokens if tok]
    features.extend(f"SB:{bg}" for bg in skeleton_to_bigrams(tokens))
    return features


def build_skeleton_bigram_vocab(samples: List[Sample]) -> Dict[str, int]:
    items: List[str] = []
    for sample in samples:
        toks = extract_normalized_skeleton_tokens(sample)
        items.extend(skeleton_to_features(toks))
    # Keep frequent structural patterns and drop overly specific one-off
    # template traces that tend to dominate some languages such as Rust.
    return build_vocab_with_min_freq(items, min_freq=2)


def vectorize_key_nodes(sample: Sample, key_vocab: Dict[str, int]) -> np.ndarray:
    vec = np.zeros(len(key_vocab), dtype=np.float32)
    for name in extract_key_node_features(sample):
        if name in key_vocab:
            vec[key_vocab[name]] += 1.0
    return vec


def vectorize_anchors(sample: Sample, anchor_vocab: Dict[str, int]) -> Tuple[np.ndarray, np.ndarray]:
    bin_vec = np.zeros(len(anchor_vocab), dtype=np.float32)
    cnt_vec = np.zeros(len(anchor_vocab), dtype=np.float32)

    for name in extract_anchor_features(sample):
        if name in anchor_vocab:
            idx = anchor_vocab[name]
            bin_vec[idx] = 1.0
            cnt_vec[idx] += 1.0
    return bin_vec, cnt_vec


def vectorize_skeleton_bigrams(
    sample: Sample,
    bigram_vocab: Dict[str, int],
) -> Tuple[np.ndarray, List[str], List[str]]:
    tokens = extract_normalized_skeleton_tokens(sample)
    bigrams = skeleton_to_bigrams(tokens)
    features = skeleton_to_features(tokens)
    vec = np.zeros(len(bigram_vocab), dtype=np.float32)
    for item in features:
        if item in bigram_vocab:
            vec[bigram_vocab[item]] += 1.0
    return vec, tokens, bigrams


def vectorize_summary_flags(sample: Sample) -> np.ndarray:
    anchors = set(extract_anchors(sample))

    def starts_with_any(prefixes: Sequence[str]) -> bool:
        return any(any(anchor.startswith(prefix) for prefix in prefixes) for anchor in anchors)

    has_input_source = float(starts_with_any(["InputSource"]))
    has_command_binding = float(starts_with_any(["DataBinding(Command)"]))
    has_command_construction = float(starts_with_any(["CommandConstruction"]))
    has_command_execution = float(starts_with_any(["DangerousCommandExecution", "ProcessInvocation", "ProcessWait"]))
    has_network_request = float(starts_with_any(["NetworkRequest"]))
    has_url_or_payload_construction = float(
        starts_with_any(["URLConstruction", "PayloadConstruction", "DataBinding(URL)", "DataBinding(Payload)"])
    )
    has_response_parsing = float(starts_with_any(["ResponseParsing", "ResponseHeaderRead", "ContentLengthRead"]))
    has_file_include = float(starts_with_any(["FileIncludeSink", "ValueReturn(FileInclude", "FileRead(LocalFile)"]))
    has_path_construction = float(starts_with_any(["PathConstruction", "DataBinding(Path)"]))
    has_archive_extraction = float(starts_with_any(["ArchiveExtraction", "LoopTraversal(ArchiveEntries)", "FileRead(ArchiveOpen)"]))
    has_file_write = float(starts_with_any(["FileWrite"]))
    has_markup_rendering = float(starts_with_any(["MarkupRendering", "UnsafeMarkupRendering"]))
    has_header_injection = float(starts_with_any(["ProtocolHeaderInjection", "RequestHeaderWrite", "RequestMetadataWrite"]))
    has_security_guard = float(starts_with_any(["SecurityEnforcement", "SecurityConfiguration", "SecurityConfig", "Sanitization"]))
    has_validation_check = float(starts_with_any(["ValidationCheck", "PathSafetyCheck", "ValidationFailureAbort"]))
    has_exception_recovery = float(starts_with_any(["ExceptionHandling", "FallbackRecovery"]))

    return np.array(
        [
            has_input_source,
            has_command_binding,
            has_command_construction,
            has_command_execution,
            has_network_request,
            has_url_or_payload_construction,
            has_response_parsing,
            has_file_include,
            has_path_construction,
            has_archive_extraction,
            has_file_write,
            has_markup_rendering,
            has_header_injection,
            has_security_guard,
            has_validation_check,
            has_exception_recovery,
        ],
        dtype=np.float32,
    )

def l2_normalize_vec(vec: np.ndarray) -> np.ndarray:
    norm = float(np.linalg.norm(vec))
    if norm < 1e-8:
        return vec.astype(np.float32, copy=False)
    return (vec / norm).astype(np.float32, copy=False)


def vectorize_sample(
    sample: Sample,
    key_vocab: Dict[str, int],
    anchor_vocab: Dict[str, int],
    bigram_vocab: Dict[str, int],
    group_mode: str = "code_hash",
    use_key_nodes: bool = True,
    use_anchors: bool = True,
    use_skeleton: bool = True,
) -> Dict[str, Any]:
    feature_switches = normalize_feature_switches(
        use_key_nodes=use_key_nodes,
        use_anchors=use_anchors,
        use_skeleton=use_skeleton,
    )

    key_vec = vectorize_key_nodes(sample, key_vocab) if feature_switches["use_key_nodes"] else np.zeros(len(key_vocab), dtype=np.float32)

    if feature_switches["use_anchors"]:
        anchor_bin_vec, anchor_cnt_vec = vectorize_anchors(sample, anchor_vocab)
    else:
        anchor_bin_vec = np.zeros(len(anchor_vocab), dtype=np.float32)
        anchor_cnt_vec = np.zeros(len(anchor_vocab), dtype=np.float32)

    if feature_switches["use_skeleton"]:
        skel_vec, skel_tokens, skel_bigrams = vectorize_skeleton_bigrams(sample, bigram_vocab)
    else:
        skel_vec = np.zeros(len(bigram_vocab), dtype=np.float32)
        skel_tokens = extract_normalized_skeleton_tokens(sample)
        skel_bigrams = skeleton_to_bigrams(skel_tokens)

    summary_vec = vectorize_summary_flags(sample) if feature_switches["use_summary_flags"] else np.zeros(len(SUMMARY_FLAG_NAMES), dtype=np.float32)

    # RQ3-v2 feature fusion:
    # 1) remove raw anchor-count features from the final vector so anchors do
    #    not dominate by repeated occurrence counts;
    # 2) L2-normalize each active block before concatenation to keep high-
    #    dimensional key-node and skeleton blocks from destabilizing MAML.
    key_vec = l2_normalize_vec(key_vec)
    anchor_bin_vec = l2_normalize_vec(anchor_bin_vec)
    skel_vec = l2_normalize_vec(skel_vec)
    summary_vec = l2_normalize_vec(summary_vec)

    feature = np.concatenate(
        [key_vec, anchor_bin_vec, skel_vec, summary_vec],
        axis=0,
    )
    feature_block_dims = {
        "key": int(len(key_vocab)),
        "anchor": int(len(anchor_vocab)),
        "skeleton": int(len(bigram_vocab)),
        "summary": int(len(SUMMARY_FLAG_NAMES)),
    }
    group_id, code_group_id, template_family_id = choose_group_id(sample, group_mode=group_mode)

    return {
        "sample_id": sample.sample_id,
        "proc_name": sample.proc_name,
        "dataset_label": sample.dataset_label,
        "binary_label": sample.binary_label,
        "label": sample.label,
        "notes": sample.notes,
        "skeleton_field_used": sample.skeleton_field_used,
        "group_id": group_id,
        "code_group_id": code_group_id,
        "template_family_id": template_family_id,
        "key_nodes": extract_key_nodes(sample),
        "key_node_features": extract_key_node_features(sample),
        "anchors": extract_anchors(sample),
        "anchor_features": extract_anchor_features(sample),
        "anchor_count_features_used_in_final_vector": False,
        "key_nodes_are_normalized": True,
        "summary_flags_default_enabled": False,
        "skeleton_tokens": skel_tokens,
        "skeleton_bigrams": skel_bigrams,
        "feature": feature,
        "feature_block_dims": feature_block_dims,
        "feature_switches": feature_switches,
    }

def vectorize_samples(
    samples: List[Sample],
    key_vocab: Dict[str, int],
    anchor_vocab: Dict[str, int],
    bigram_vocab: Dict[str, int],
    group_mode: str = "code_hash",
    use_key_nodes: bool = True,
    use_anchors: bool = True,
    use_skeleton: bool = True,
) -> List[Dict[str, Any]]:
    return [
        vectorize_sample(
            sample,
            key_vocab,
            anchor_vocab,
            bigram_vocab,
            group_mode=group_mode,
            use_key_nodes=use_key_nodes,
            use_anchors=use_anchors,
            use_skeleton=use_skeleton,
        )
        for sample in samples
    ]


def save_vocabs(
    output_dir: Path,
    key_vocab: Dict[str, int],
    anchor_vocab: Dict[str, int],
    bigram_vocab: Dict[str, int],
    skeleton_field: str = "auto",
    label_names: Optional[List[str]] = None,
    feature_switches: Optional[Dict[str, bool]] = None,
) -> Path:
    normalized_feature_switches = normalize_feature_switches(**(feature_switches or {}))
    vocab_obj = {
        "key_node_vocab": key_vocab,
        "anchor_vocab": anchor_vocab,
        "skeleton_bigram_vocab": bigram_vocab,
        "summary_flag_names": SUMMARY_FLAG_NAMES,
        "feature_block_order": FEATURE_BLOCK_ORDER,
        "feature_block_dims": {
            "key": int(len(key_vocab)),
            "anchor": int(len(anchor_vocab)),
            "skeleton": int(len(bigram_vocab)),
            "summary": int(len(SUMMARY_FLAG_NAMES)),
        },
        "skeleton_field_preference": skeleton_field,
        "label_names": label_names or [],
        "id_to_label": {str(i): name for i, name in enumerate(label_names or [])},
        "label_to_id": {name: i for i, name in enumerate(label_names or [])},
        "feature_switches": normalized_feature_switches,
        "feature_switch_tag": feature_switches_to_tag(normalized_feature_switches),
    }
    path = output_dir / "vocabs.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(vocab_obj, f, ensure_ascii=False, indent=2)
    return path

def load_vocabs(vocabs_json: str) -> Tuple[Dict[str, int], Dict[str, int], Dict[str, int], str, List[str], Dict[str, bool]]:
    with open(vocabs_json, "r", encoding="utf-8") as f:
        obj = json.load(f)
    label_names = [str(x) for x in obj.get("label_names", [])]
    if not label_names and obj.get("id_to_label"):
        id_to_label = {int(k): str(v) for k, v in obj["id_to_label"].items()}
        label_names = [id_to_label[i] for i in sorted(id_to_label)]
    feature_switches = normalize_feature_switches(**(obj.get("feature_switches") or {}))
    return (
        {str(k): int(v) for k, v in obj["key_node_vocab"].items()},
        {str(k): int(v) for k, v in obj["anchor_vocab"].items()},
        {str(k): int(v) for k, v in obj["skeleton_bigram_vocab"].items()},
        str(obj.get("skeleton_field_preference", "auto")),
        label_names,
        feature_switches,
    )

def save_jsonl(output_dir: Path, rows: List[Dict[str, Any]], filename: str = "sample_features.jsonl") -> Path:
    path = output_dir / filename
    with open(path, "w", encoding="utf-8") as f:
        for row in rows:
            out = dict(row)
            out["feature"] = row["feature"].tolist()
            f.write(json.dumps(out, ensure_ascii=False) + "\n")
    return path


def rows_to_arrays(rows: List[Dict[str, Any]]) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    X = np.stack([row["feature"] for row in rows], axis=0).astype(np.float32)
    y = np.array([row["label"] for row in rows], dtype=np.int64)
    names = np.array([row.get("sample_id", row["proc_name"]) for row in rows], dtype=object)
    return X, y, names

def save_npz_from_rows(
    output_path: Path,
    rows: List[Dict[str, Any]],
    label_names: Optional[List[str]] = None,
) -> Path:
    X, y, proc_names = rows_to_arrays(rows)
    raw_proc_names = np.array([row["proc_name"] for row in rows], dtype=object)
    group_ids = np.array([row.get("group_id", "") for row in rows], dtype=object)
    code_group_ids = np.array([row.get("code_group_id", "") for row in rows], dtype=object)
    template_family_ids = np.array([row.get("template_family_id", "") for row in rows], dtype=object)
    save_kwargs = {
        "X": X,
        "y": y,
        "proc_names": proc_names,
        "raw_proc_names": raw_proc_names,
        "group_ids": group_ids,
        "code_group_ids": code_group_ids,
        "template_family_ids": template_family_ids,
    }
    if rows:
        block_dims = rows[0].get("feature_block_dims")
        if isinstance(block_dims, dict):
            save_kwargs["feature_block_order"] = np.array(FEATURE_BLOCK_ORDER, dtype=object)
            save_kwargs["feature_block_dims"] = np.array(
                [int(block_dims.get(name, 0)) for name in FEATURE_BLOCK_ORDER],
                dtype=np.int64,
            )
    if label_names is not None:
        save_kwargs["label_names"] = np.array(label_names, dtype=object)
    np.savez(output_path, **save_kwargs)
    return output_path

def build_confusion_matrix(golds: Sequence[int], preds: Sequence[int], num_classes: int) -> np.ndarray:
    cm = np.zeros((num_classes, num_classes), dtype=np.int64)
    for g, p in zip(golds, preds):
        if 0 <= int(g) < num_classes and 0 <= int(p) < num_classes:
            cm[int(g), int(p)] += 1
    return cm


def compute_classification_metrics(
    golds: Sequence[int],
    preds: Sequence[int],
    label_names: Optional[Sequence[str]] = None,
    label_ids: Optional[Sequence[int]] = None,
) -> Dict[str, Any]:
    golds = [int(x) for x in golds]
    preds = [int(x) for x in preds]
    if not golds:
        raise ValueError("golds 为空，无法计算分类指标。")

    if label_ids is None:
        chosen_label_ids = sorted(set(golds) | set(preds))
    else:
        chosen_label_ids = [int(x) for x in label_ids]
        if not chosen_label_ids:
            raise ValueError("label_ids 为空，无法计算分类指标。")

    id_to_pos = {lab: idx for idx, lab in enumerate(chosen_label_ids)}
    cm = np.zeros((len(chosen_label_ids), len(chosen_label_ids)), dtype=np.int64)
    for g, p in zip(golds, preds):
        if g in id_to_pos and p in id_to_pos:
            cm[id_to_pos[g], id_to_pos[p]] += 1

    if label_names is None:
        names = [str(lab) for lab in chosen_label_ids]
    else:
        raw_names = [str(x) for x in label_names]
        names = [raw_names[lab] if 0 <= lab < len(raw_names) else str(lab) for lab in chosen_label_ids]

    per_class: Dict[str, Any] = {}
    macro_p = macro_r = macro_f1 = 0.0
    weighted_p = weighted_r = weighted_f1 = 0.0
    total = len(golds)
    num_classes = len(chosen_label_ids)

    for local_idx, global_label_id in enumerate(chosen_label_ids):
        tp = int(cm[local_idx, local_idx])
        fp = int(cm[:, local_idx].sum() - tp)
        fn = int(cm[local_idx, :].sum() - tp)
        support = int(cm[local_idx, :].sum())
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) > 0 else 0.0
        per_class[names[local_idx]] = {
            "label_id": int(global_label_id),
            "precision": float(precision),
            "recall": float(recall),
            "f1": float(f1),
            "support": support,
        }
        macro_p += precision
        macro_r += recall
        macro_f1 += f1
        weighted_p += precision * support
        weighted_r += recall * support
        weighted_f1 += f1 * support

    accuracy = float(np.mean(np.array(golds) == np.array(preds))) if total else 0.0
    macro_p /= num_classes
    macro_r /= num_classes
    macro_f1 /= num_classes
    weighted_p = weighted_p / total if total else 0.0
    weighted_r = weighted_r / total if total else 0.0
    weighted_f1 = weighted_f1 / total if total else 0.0

    return {
        "num_samples": total,
        "accuracy": float(accuracy),
        "macro_precision": float(macro_p),
        "macro_recall": float(macro_r),
        "macro_f1": float(macro_f1),
        "weighted_precision": float(weighted_p),
        "weighted_recall": float(weighted_r),
        "weighted_f1": float(weighted_f1),
        "labels": names,
        "label_ids": [int(x) for x in chosen_label_ids],
        "confusion_matrix": cm.tolist(),
        "per_class": per_class,
    }


def run_baseline(output_dir: Path, rows: List[Dict[str, Any]], label_names: Optional[List[str]] = None) -> None:
    try:
        from sklearn.linear_model import LogisticRegression
        from sklearn.model_selection import LeaveOneOut
    except Exception as e:
        raise RuntimeError("运行 baseline 需要 scikit-learn。请先安装 sklearn。") from e

    X, y, proc_names = rows_to_arrays(rows)
    names = proc_names.tolist()

    loo = LeaveOneOut()
    preds: List[int] = []
    golds: List[int] = []
    per_case: List[Dict[str, Any]] = []

    for train_idx, test_idx in loo.split(X):
        X_train, X_test = X[train_idx], X[test_idx]
        y_train, y_test = y[train_idx], y[test_idx]

        clf = LogisticRegression(max_iter=1000, class_weight="balanced", multi_class="auto")
        clf.fit(X_train, y_train)
        pred = int(clf.predict(X_test)[0])

        preds.append(pred)
        golds.append(int(y_test[0]))
        row = {
            "proc_name": names[test_idx[0]],
            "gold": int(y_test[0]),
            "pred": pred,
        }
        if label_names and 0 <= int(y_test[0]) < len(label_names):
            row["gold_label"] = label_names[int(y_test[0])]
        if label_names and 0 <= pred < len(label_names):
            row["pred_label"] = label_names[pred]
        per_case.append(row)

    label_ids = list(range(len(label_names))) if label_names is not None else None
    report = compute_classification_metrics(golds, preds, label_names=label_names, label_ids=label_ids)
    report.update({
        "setting": "Leave-One-Out on current dataset",
        "per_case": per_case,
        "note": "该结果仅用于验证流程是否跑通，不代表正式泛化性能。",
    })

    with open(output_dir / "baseline_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)


def build_structural_features_from_json(
    input_json: str,
    labels_json: Optional[str],
    output_dir: str,
    run_baseline_flag: bool = False,
    skeleton_field: str = "auto",
    group_mode: str = "code_hash",
    use_key_nodes: bool = True,
    use_anchors: bool = True,
    use_skeleton: bool = True,
    vocab_sample_indices: Optional[List[int]] = None,
) -> Dict[str, Any]:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    labels_map = load_labels(labels_json)
    preferred_label_to_id = load_label_order(labels_json)
    samples = load_samples(
        input_json,
        labels_map=labels_map,
        require_label=True,
        skeleton_field=skeleton_field,
        dataset_label_to_id=preferred_label_to_id if preferred_label_to_id else None,
    )
    label_to_id, id_to_label, label_names = derive_label_space_from_samples(samples)
    feature_switches = normalize_feature_switches(
        use_key_nodes=use_key_nodes,
        use_anchors=use_anchors,
        use_skeleton=use_skeleton,
    )

    if vocab_sample_indices is None:
        vocab_samples = samples
        vocab_source = "all_samples"
    else:
        vocab_index_set = {int(i) for i in vocab_sample_indices if 0 <= int(i) < len(samples)}
        if not vocab_index_set:
            raise ValueError("vocab_sample_indices 为空，无法构建词表。")
        vocab_samples = [samples[i] for i in sorted(vocab_index_set)]
        vocab_source = "train_split_only"

    key_vocab = build_key_node_vocab(vocab_samples)
    anchor_vocab = build_anchor_vocab(vocab_samples)
    bigram_vocab = build_skeleton_bigram_vocab(vocab_samples)

    rows = vectorize_samples(
        samples,
        key_vocab,
        anchor_vocab,
        bigram_vocab,
        group_mode=group_mode,
        use_key_nodes=feature_switches["use_key_nodes"],
        use_anchors=feature_switches["use_anchors"],
        use_skeleton=feature_switches["use_skeleton"],
    )
    save_vocabs(
        out_dir,
        key_vocab,
        anchor_vocab,
        bigram_vocab,
        skeleton_field=skeleton_field,
        label_names=label_names,
        feature_switches=feature_switches,
    )
    save_jsonl(out_dir, rows, filename="sample_features.jsonl")
    npz_path = save_npz_from_rows(out_dir / "maml_ready_features.npz", rows, label_names=label_names)

    label_space_path = out_dir / "label_space.json"
    label_space_path.write_text(
        json.dumps(
            {
                "label_to_id": label_to_id,
                "id_to_label": {str(k): v for k, v in id_to_label.items()},
                "label_names": label_names,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    if run_baseline_flag:
        run_baseline(out_dir, rows, label_names=label_names)

    return {
        "rows": rows,
        "npz_path": str(npz_path),
        "num_samples": len(rows),
        "input_dim": int(len(rows[0]["feature"])) if rows else 0,
        "key_vocab_size": len(key_vocab),
        "anchor_vocab_size": len(anchor_vocab),
        "bigram_vocab_size": len(bigram_vocab),
        "skeleton_field": skeleton_field,
        "group_mode": group_mode,
        "num_code_groups": len({row.get("group_id", "") for row in rows}),
        "label_names": label_names,
        "num_classes": len(label_names),
        "label_space_path": str(label_space_path),
        "feature_switches": feature_switches,
        "feature_switch_tag": feature_switches_to_tag(feature_switches),
        "vocab_source": vocab_source,
        "vocab_num_samples": len(vocab_samples),
        "rq3_v2_feature_design": {
            "key_nodes": "normalized + expanded core/family, min_freq=1",
            "anchors": "normalized payload buckets + family",
            "skeleton_default": "key_skeleton first; unigram + bigram features",
            "summary_flags_default": "off",
            "anchor_count_in_final_vector": False,
            "module_l2_normalization": True,
            "train_only_vocab_for_train_json": vocab_source == "train_split_only",
        },
    }


def resolve_plm_model_name(feature_extractor: str, model_name_or_path: Optional[str] = None) -> str:
    extractor = str(feature_extractor or "codebert").strip().lower()
    if extractor not in PLM_MODEL_NAMES:
        raise ValueError(f"未知 PLM 特征提取器: {feature_extractor}。可选: {sorted(PLM_MODEL_NAMES)}")
    return str(model_name_or_path or PLM_MODEL_NAMES[extractor])


def _load_plm_tokenizer_and_model(
    feature_extractor: str,
    model_name_or_path: Optional[str] = None,
    device: str = "cpu",
):
    try:
        from transformers import AutoModel, AutoTokenizer
    except Exception as e:
        raise RuntimeError(
            "运行 CodeBERT / GraphCodeBERT / UniXCoder 特征提取需要安装 transformers。"
            "请先执行: pip install transformers"
        ) from e

    model_name = resolve_plm_model_name(feature_extractor, model_name_or_path)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name)
    model.to(device)
    model.eval()
    return tokenizer, model, model_name


def _pool_plm_outputs(outputs: Any, attention_mask: torch.Tensor, pooling: str = "cls") -> torch.Tensor:
    last_hidden = outputs.last_hidden_state
    pooling = str(pooling or "cls").lower()
    if pooling == "cls":
        return last_hidden[:, 0, :]
    if pooling == "mean":
        mask = attention_mask.unsqueeze(-1).to(last_hidden.dtype)
        summed = (last_hidden * mask).sum(dim=1)
        denom = mask.sum(dim=1).clamp_min(1e-6)
        return summed / denom
    raise ValueError(f"未知 pooling: {pooling}，可选 cls / mean")


@torch.no_grad()
def extract_plm_embeddings(
    codes: Sequence[str],
    feature_extractor: str = "codebert",
    model_name_or_path: Optional[str] = None,
    max_length: int = 512,
    batch_size: int = 8,
    pooling: str = "cls",
    l2_normalize: bool = False,
    device: str = "cpu",
) -> Tuple[np.ndarray, Dict[str, Any]]:
    tokenizer, model, resolved_model_name = _load_plm_tokenizer_and_model(
        feature_extractor=feature_extractor,
        model_name_or_path=model_name_or_path,
        device=device,
    )

    features: List[np.ndarray] = []
    code_list = [str(code or "") for code in codes]
    batch_size = max(1, int(batch_size))
    max_length = max(8, int(max_length))

    for start in range(0, len(code_list), batch_size):
        batch_codes = code_list[start:start + batch_size]
        inputs = tokenizer(
            batch_codes,
            padding=True,
            truncation=True,
            max_length=max_length,
            return_tensors="pt",
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}
        outputs = model(**inputs)
        pooled = _pool_plm_outputs(outputs, inputs["attention_mask"], pooling=pooling)
        if l2_normalize:
            pooled = F.normalize(pooled, p=2, dim=-1)
        features.append(pooled.detach().cpu().numpy().astype(np.float32))

    if not features:
        X = np.zeros((0, 0), dtype=np.float32)
    else:
        X = np.concatenate(features, axis=0).astype(np.float32)

    meta = {
        "feature_extractor": str(feature_extractor),
        "model_name_or_path": resolved_model_name,
        "max_length": int(max_length),
        "batch_size": int(batch_size),
        "pooling": str(pooling),
        "l2_normalize": bool(l2_normalize),
        "embedding_dim": int(X.shape[1]) if X.ndim == 2 and X.shape[0] > 0 else 0,
    }
    return X, meta


def plm_rows_from_samples(
    samples: List[Sample],
    X: np.ndarray,
    group_mode: str = "code_hash",
    plm_meta: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    plm_meta = plm_meta or {}
    for sample, feature in zip(samples, X):
        group_id, code_group_id, template_family_id = choose_group_id(sample, group_mode=group_mode)
        rows.append({
            "sample_id": sample.sample_id,
            "proc_name": sample.proc_name,
            "dataset_label": sample.dataset_label,
            "binary_label": sample.binary_label,
            "label": sample.label,
            "notes": sample.notes,
            "skeleton_field_used": sample.skeleton_field_used,
            "group_id": group_id,
            "code_group_id": code_group_id,
            "template_family_id": template_family_id,
            "feature_extractor": plm_meta.get("feature_extractor", "plm"),
            "plm_model_name_or_path": plm_meta.get("model_name_or_path", ""),
            "plm_pooling": plm_meta.get("pooling", "cls"),
            "plm_max_length": plm_meta.get("max_length", 512),
            "plm_l2_normalize": plm_meta.get("l2_normalize", False),
            "code_length_chars": len(str(sample.code or "")),
            "feature": np.asarray(feature, dtype=np.float32),
        })
    return rows


def save_plm_config(
    output_dir: Path,
    plm_meta: Dict[str, Any],
    label_names: Optional[List[str]] = None,
) -> Path:
    obj = dict(plm_meta)
    obj.update({
        "label_names": label_names or [],
        "id_to_label": {str(i): name for i, name in enumerate(label_names or [])},
        "label_to_id": {name: i for i, name in enumerate(label_names or [])},
        "note": "PLM baseline: raw code is encoded by a frozen CodeBERT / GraphCodeBERT / UniXCoder encoder; hand-crafted key nodes, anchors and skeleton features are not used.",
    })
    path = output_dir / "plm_feature_config.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    return path


def build_plm_features_from_json(
    input_json: str,
    labels_json: Optional[str],
    output_dir: str,
    run_baseline_flag: bool = False,
    skeleton_field: str = "auto",
    group_mode: str = "code_hash",
    feature_extractor: str = "codebert",
    plm_model_name_or_path: Optional[str] = None,
    plm_max_length: int = 512,
    plm_batch_size: int = 8,
    plm_pooling: str = "cls",
    plm_l2_normalize: bool = False,
    cpu: bool = False,
) -> Dict[str, Any]:
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    labels_map = load_labels(labels_json)
    preferred_label_to_id = load_label_order(labels_json)
    samples = load_samples(
        input_json,
        labels_map=labels_map,
        require_label=True,
        skeleton_field=skeleton_field,
        dataset_label_to_id=preferred_label_to_id if preferred_label_to_id else None,
    )
    label_to_id, id_to_label, label_names = derive_label_space_from_samples(samples)

    device = "cuda" if torch.cuda.is_available() and not cpu else "cpu"
    X, plm_meta = extract_plm_embeddings(
        codes=[sample.code for sample in samples],
        feature_extractor=feature_extractor,
        model_name_or_path=plm_model_name_or_path,
        max_length=plm_max_length,
        batch_size=plm_batch_size,
        pooling=plm_pooling,
        l2_normalize=plm_l2_normalize,
        device=device,
    )
    rows = plm_rows_from_samples(samples, X, group_mode=group_mode, plm_meta=plm_meta)

    save_jsonl(out_dir, rows, filename="sample_features.jsonl")
    npz_path = save_npz_from_rows(out_dir / "maml_ready_features.npz", rows, label_names=label_names)
    plm_config_path = save_plm_config(out_dir, plm_meta, label_names=label_names)

    label_space_path = out_dir / "label_space.json"
    label_space_path.write_text(
        json.dumps(
            {
                "label_to_id": label_to_id,
                "id_to_label": {str(k): v for k, v in id_to_label.items()},
                "label_names": label_names,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    if run_baseline_flag:
        run_baseline(out_dir, rows, label_names=label_names)

    return {
        "rows": rows,
        "npz_path": str(npz_path),
        "num_samples": len(rows),
        "input_dim": int(X.shape[1]) if X.ndim == 2 else 0,
        "feature_extractor": feature_extractor,
        "plm_model_name_or_path": plm_meta.get("model_name_or_path", ""),
        "plm_pooling": plm_pooling,
        "plm_max_length": int(plm_max_length),
        "plm_batch_size": int(plm_batch_size),
        "plm_l2_normalize": bool(plm_l2_normalize),
        "skeleton_field": skeleton_field,
        "group_mode": group_mode,
        "num_code_groups": len({row.get("group_id", "") for row in rows}),
        "label_names": label_names,
        "num_classes": len(label_names),
        "label_space_path": str(label_space_path),
        "plm_config_path": str(plm_config_path),
        "vocab_source": "not_applicable_plm_encoder",
        "vocab_num_samples": 0,
        "rq3_plm_baseline_design": {
            "feature_source": "raw code only",
            "encoder": feature_extractor,
            "model_name_or_path": plm_meta.get("model_name_or_path", ""),
            "pooling": plm_pooling,
            "max_length": int(plm_max_length),
            "handcrafted_key_nodes_used": False,
            "security_anchors_used": False,
            "skeleton_features_used": False,
            "downstream_training": "same first-order MAML pipeline and grouped split as structural features",
        },
    }


def build_features_from_json(
    input_json: str,
    labels_json: Optional[str],
    output_dir: str,
    run_baseline_flag: bool = False,
    skeleton_field: str = "auto",
    group_mode: str = "code_hash",
    use_key_nodes: bool = True,
    use_anchors: bool = True,
    use_skeleton: bool = True,
    vocab_sample_indices: Optional[List[int]] = None,
    feature_extractor: str = "structural",
    plm_model_name_or_path: Optional[str] = None,
    plm_max_length: int = 512,
    plm_batch_size: int = 8,
    plm_pooling: str = "cls",
    plm_l2_normalize: bool = False,
    cpu: bool = False,
) -> Dict[str, Any]:
    extractor = str(feature_extractor or "structural").strip().lower()
    if extractor == "structural":
        return build_structural_features_from_json(
            input_json=input_json,
            labels_json=labels_json,
            output_dir=output_dir,
            run_baseline_flag=run_baseline_flag,
            skeleton_field=skeleton_field,
            group_mode=group_mode,
            use_key_nodes=use_key_nodes,
            use_anchors=use_anchors,
            use_skeleton=use_skeleton,
            vocab_sample_indices=vocab_sample_indices,
        )
    if extractor in PLM_MODEL_NAMES:
        return build_plm_features_from_json(
            input_json=input_json,
            labels_json=labels_json,
            output_dir=output_dir,
            run_baseline_flag=run_baseline_flag,
            skeleton_field=skeleton_field,
            group_mode=group_mode,
            feature_extractor=extractor,
            plm_model_name_or_path=plm_model_name_or_path,
            plm_max_length=plm_max_length,
            plm_batch_size=plm_batch_size,
            plm_pooling=plm_pooling,
            plm_l2_normalize=plm_l2_normalize,
            cpu=cpu,
        )
    raise ValueError(f"未知 feature_extractor: {feature_extractor}。可选 structural / codebert / graphcodebert / unixcoder")

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def load_feature_npz(npz_path: str, require_y: bool = True) -> Tuple[np.ndarray, Optional[np.ndarray], List[str]]:
    data = np.load(npz_path, allow_pickle=True)
    X = data["X"].astype(np.float32)
    if "y" in data.files:
        y: Optional[np.ndarray] = data["y"].astype(np.int64)
    elif require_y:
        raise ValueError(f"NPZ 文件 {npz_path} 缺少 y 字段。当前模式要求标签。")
    else:
        y = None
    proc_names = data["proc_names"].tolist() if "proc_names" in data.files else [str(i) for i in range(len(X))]
    return X, y, proc_names


def load_feature_npz_meta(
    npz_path: str,
    require_y: bool = True,
) -> Tuple[np.ndarray, Optional[np.ndarray], List[str], Optional[List[str]], Optional[List[str]], Optional[List[str]], Optional[List[str]]]:
    data = np.load(npz_path, allow_pickle=True)
    X = data["X"].astype(np.float32)
    if "y" in data.files:
        y: Optional[np.ndarray] = data["y"].astype(np.int64)
    elif require_y:
        raise ValueError(f"NPZ 文件 {npz_path} 缺少 y 字段。当前模式要求标签。")
    else:
        y = None
    proc_names = data["proc_names"].tolist() if "proc_names" in data.files else [str(i) for i in range(len(X))]
    group_ids = data["group_ids"].tolist() if "group_ids" in data.files else None
    code_group_ids = data["code_group_ids"].tolist() if "code_group_ids" in data.files else None
    template_family_ids = data["template_family_ids"].tolist() if "template_family_ids" in data.files else None
    label_names = data["label_names"].tolist() if "label_names" in data.files else None
    if label_names is not None:
        label_names = [str(x) for x in label_names]
    return X, y, proc_names, group_ids, label_names, code_group_ids, template_family_ids


def load_feature_block_dims(npz_path: str, input_dim: Optional[int] = None) -> Optional[Dict[str, int]]:
    data = np.load(npz_path, allow_pickle=True)
    if "feature_block_dims" not in data.files:
        return None
    raw_dims = [int(x) for x in data["feature_block_dims"].tolist()]
    raw_order = data["feature_block_order"].tolist() if "feature_block_order" in data.files else FEATURE_BLOCK_ORDER
    order = [str(x) for x in raw_order]
    dims = {name: int(dim) for name, dim in zip(order, raw_dims)}
    if input_dim is not None and sum(dims.values()) != int(input_dim):
        return None
    return {name: int(dims.get(name, 0)) for name in FEATURE_BLOCK_ORDER}


def class_counts(y: np.ndarray) -> Dict[int, int]:
    uniq, counts = np.unique(y, return_counts=True)
    return {int(k): int(v) for k, v in zip(uniq, counts)}


def compute_split_plan(
    y: np.ndarray,
    k_shot: int,
    q_query: int,
    force_no_val: bool = False,
    val_per_class: int = 10,
    test_per_class: int = 10,
    min_train_per_class: int = 20,
):
    counts = class_counts(y)
    eval_min = k_shot + q_query
    desired_val = max(eval_min, int(val_per_class))
    desired_test = max(eval_min, int(test_per_class))
    desired_train = max(eval_min, int(min_train_per_class))
    small_holdout_ratio = 0.25

    if any(v < 2 * eval_min for v in counts.values()):
        raise ValueError(
            f"样本太少，无法同时保证 train 和 test 都能按 {k_shot}-shot / {q_query}-query 采样。每类样本数: {counts}"
        )

    has_val = (not force_no_val) and all(v >= 3 * eval_min for v in counts.values())

    plan: Dict[int, Dict[str, int]] = {}
    for c, n in counts.items():
        if has_val:
            if n >= desired_train + desired_val + desired_test:
                n_val = desired_val
                n_test = desired_test
                n_train = n - n_val - n_test
            else:
                # 数据量不足以维持 Nim 那样的 10/10 holdout 时，退回到最小可行 held-out split
                n_val = eval_min
                n_test = eval_min
                n_train = n - n_val - n_test
        else:
            # 没有独立 validation 时，test 不再一律压到 eval_min；
            # 对中小类按比例保留更多 held-out 测试样本，尽量让评估更稳定。
            max_test_allow = max(eval_min, n - eval_min)
            adaptive_test = max(eval_min, int(math.ceil(n * small_holdout_ratio)))
            if n >= desired_train + desired_test:
                n_test = desired_test
            else:
                n_test = min(desired_test, adaptive_test, max_test_allow)
                n_test = max(eval_min, n_test)
                n_test = min(n_test, n - eval_min)
            n_val = 0
            n_train = n - n_test

        if n_train < eval_min:
            raise ValueError(
                f"类别 {c} 的训练样本不足。当前 split 计划: train={n_train}, val={n_val}, test={n_test}"
            )

        plan[c] = {"train": int(n_train), "val": int(n_val), "test": int(n_test)}

    return plan, has_val


def _pick_group_subset(
    groups: List[List[int]],
    target_count: int,
    rng: np.random.Generator,
) -> Tuple[List[List[int]], List[List[int]]]:
    if target_count <= 0:
        return [], groups

    shuffled = list(groups)
    rng.shuffle(shuffled)
    ordered = sorted(shuffled, key=lambda g: (len(g), float(rng.random())))

    chosen: List[List[int]] = []
    chosen_count = 0
    remaining: List[List[int]] = []

    for group in ordered:
        if chosen_count < target_count:
            chosen.append(group)
            chosen_count += len(group)
        else:
            remaining.append(group)

    return chosen, remaining



def _grouped_global_split_indices(
    y: np.ndarray,
    plan: Dict[int, Dict[str, int]],
    seed: int,
    group_ids: List[str],
):
    rng = np.random.default_rng(seed)
    group_to_indices: Dict[str, List[int]] = defaultdict(list)
    for idx, gid in enumerate(group_ids):
        key = str(gid) if gid else f"idx_{idx}"
        group_to_indices[key].append(int(idx))

    remaining_groups = list(group_to_indices.values())
    rng.shuffle(remaining_groups)

    def _group_class_counts(group: List[int]) -> Dict[int, int]:
        out: Dict[int, int] = defaultdict(int)
        for i in group:
            out[int(y[i])] += 1
        return dict(out)

    def _select_groups(target_key: str, pool: List[List[int]]) -> Tuple[List[List[int]], List[List[int]], Dict[int, int]]:
        target = {int(c): int(plan[int(c)][target_key]) for c in plan.keys()}
        counts: Dict[int, int] = defaultdict(int)
        chosen: List[List[int]] = []
        remaining = list(pool)

        while True:
            deficits = {c: max(0, target[c] - counts.get(c, 0)) for c in target}
            if all(v <= 0 for v in deficits.values()):
                break

            best_i = None
            best_score = -1
            best_size = None

            for gi, group in enumerate(remaining):
                gc = _group_class_counts(group)
                gain = sum(min(gc.get(c, 0), deficits.get(c, 0)) for c in deficits)
                if gain <= 0:
                    continue
                size = len(group)
                if gain > best_score or (gain == best_score and (best_size is None or size < best_size)):
                    best_i = gi
                    best_score = gain
                    best_size = size

            if best_i is None:
                break

            picked = remaining.pop(best_i)
            chosen.append(picked)
            for c, n in _group_class_counts(picked).items():
                counts[c] += n

        return chosen, remaining, counts

    test_groups, remaining_groups, _ = _select_groups("test", remaining_groups)
    val_groups, remaining_groups, _ = _select_groups("val", remaining_groups)
    train_groups = remaining_groups

    train_idx = [i for g in train_groups for i in g]
    val_idx = [i for g in val_groups for i in g]
    test_idx = [i for g in test_groups for i in g]

    rng.shuffle(train_idx)
    rng.shuffle(val_idx)
    rng.shuffle(test_idx)
    return train_idx, val_idx, test_idx


def stratified_split_indices(
    y: np.ndarray,
    plan: Dict[int, Dict[str, int]],
    seed: int,
    group_ids: Optional[List[str]] = None,
    use_group_split: bool = False,
    group_split_scope: str = "per_class",
):
    rng = np.random.default_rng(seed)
    train_idx: List[int] = []
    val_idx: List[int] = []
    test_idx: List[int] = []

    if use_group_split and group_ids is not None and group_split_scope == "global":
        return _grouped_global_split_indices(y, plan, seed, group_ids)

    if use_group_split and group_ids is not None:
        for c in sorted(plan.keys()):
            idx = np.where(y == c)[0].tolist()
            group_to_indices: Dict[str, List[int]] = defaultdict(list)
            for i in idx:
                gid = str(group_ids[i]) if group_ids[i] else f"idx_{i}"
                group_to_indices[gid].append(int(i))

            groups = list(group_to_indices.values())
            test_groups, remaining = _pick_group_subset(groups, plan[c]["test"], rng)
            val_groups, remaining = _pick_group_subset(remaining, plan[c]["val"], rng)

            test_idx.extend([i for g in test_groups for i in g])
            val_idx.extend([i for g in val_groups for i in g])
            train_idx.extend([i for g in remaining for i in g])
    else:
        for c in sorted(plan.keys()):
            idx = np.where(y == c)[0].copy()
            rng.shuffle(idx)
            n_train = plan[c]["train"]
            n_val = plan[c]["val"]
            n_test = plan[c]["test"]

            train_idx.extend(idx[:n_train].tolist())
            val_idx.extend(idx[n_train:n_train + n_val].tolist())
            test_idx.extend(idx[n_train + n_val:n_train + n_val + n_test].tolist())

    rng.shuffle(train_idx)
    rng.shuffle(val_idx)
    rng.shuffle(test_idx)
    return train_idx, val_idx, test_idx


class EpisodeSampler:
    def __init__(
        self,
        X: np.ndarray,
        y: np.ndarray,
        indices: List[int],
        n_way: int,
        k_shot: int,
        q_query: int,
        seed: int = 42,
    ):
        self.X = X
        self.y = y
        self.indices = list(indices)
        self.n_way = n_way
        self.k_shot = k_shot
        self.q_query = q_query
        self.rng = np.random.default_rng(seed)

        self.class_to_indices: Dict[int, List[int]] = defaultdict(list)
        for idx in self.indices:
            self.class_to_indices[int(y[idx])].append(int(idx))
        self.classes = sorted(self.class_to_indices.keys())

        if len(self.classes) < self.n_way:
            raise ValueError(f"当前 split 中类别数不足 {self.n_way}。实际类别: {self.classes}")

        for c in self.classes:
            if len(self.class_to_indices[c]) < self.k_shot + self.q_query:
                raise ValueError(
                    f"类别 {c} 在当前 split 中样本不足，无法做 {self.k_shot}-shot / {self.q_query}-query 采样。"
                )

    def sample_episode(self):
        chosen_classes = self.rng.choice(self.classes, size=self.n_way, replace=False).tolist()

        support_indices: List[int] = []
        query_indices: List[int] = []
        support_labels: List[int] = []
        query_labels: List[int] = []

        for new_label, c in enumerate(chosen_classes):
            idxs = np.array(self.class_to_indices[c], dtype=np.int64)
            picked = self.rng.choice(idxs, size=self.k_shot + self.q_query, replace=False)
            support = picked[:self.k_shot]
            query = picked[self.k_shot:]

            support_indices.extend(support.tolist())
            query_indices.extend(query.tolist())
            support_labels.extend([int(c)] * self.k_shot)
            query_labels.extend([int(c)] * self.q_query)

        x_s = torch.tensor(self.X[support_indices], dtype=torch.float32)
        y_s = torch.tensor(support_labels, dtype=torch.long)
        x_q = torch.tensor(self.X[query_indices], dtype=torch.float32)
        y_q = torch.tensor(query_labels, dtype=torch.long)
        return x_s, y_s, x_q, y_q


class MAMLMLP(nn.Module):
    def __init__(
        self,
        input_dim: int,
        hidden_dim: int = 64,
        embed_dim: int = 32,
        dropout: float = 0.1,
        n_classes: int = 2,
        feature_block_dims: Optional[Dict[str, int]] = None,
        use_module_gates: bool = True,
        adaptive_module_gates: bool = True,
        module_dropout: float = 0.0,
    ):
        super().__init__()
        self.feature_block_dims = feature_block_dims or {}
        self.use_module_gates = bool(use_module_gates and self.feature_block_dims)
        self.adaptive_module_gates = bool(adaptive_module_gates)
        self.module_dropout = float(max(0.0, min(0.95, module_dropout)))
        self.block_slices: List[Tuple[str, int, int]] = []
        cursor = 0
        for name in FEATURE_BLOCK_ORDER:
            dim = int(self.feature_block_dims.get(name, 0))
            if dim > 0:
                self.block_slices.append((name, cursor, cursor + dim))
                cursor += dim
        if self.use_module_gates and cursor == input_dim:
            init = torch.log(torch.expm1(torch.ones(len(self.block_slices))))
            self.block_gate_logits = nn.Parameter(init)
            if self.adaptive_module_gates:
                gate_hidden = max(8, min(32, hidden_dim // 2))
                self.dynamic_gate = nn.Sequential(
                    nn.Linear(len(self.block_slices) * 3, gate_hidden),
                    nn.ReLU(),
                    nn.Linear(gate_hidden, len(self.block_slices)),
                )
            else:
                self.dynamic_gate = None
        else:
            self.use_module_gates = False
            self.block_gate_logits = None
            self.dynamic_gate = None
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, embed_dim),
            nn.ReLU(),
        )
        self.classifier = nn.Linear(embed_dim, n_classes)

    def _apply_module_gates(self, x: torch.Tensor) -> torch.Tensor:
        if not self.use_module_gates or self.block_gate_logits is None:
            return x
        static_gates = F.softplus(self.block_gate_logits).view(1, -1)
        gates = static_gates
        if self.dynamic_gate is not None:
            summaries = []
            for _name, start, end in self.block_slices:
                block = x[..., start:end]
                abs_block = block.abs()
                summaries.append(abs_block.mean(dim=-1, keepdim=True))
                summaries.append(torch.sqrt((block * block).mean(dim=-1, keepdim=True) + 1e-8))
                summaries.append((abs_block > 1e-8).float().mean(dim=-1, keepdim=True))
            dynamic_logits = self.dynamic_gate(torch.cat(summaries, dim=-1))
            dynamic_gates = F.softmax(dynamic_logits, dim=-1) * len(self.block_slices)
            gates = gates * dynamic_gates

        if self.training and self.module_dropout > 0.0 and len(self.block_slices) > 1:
            keep = (torch.rand(gates.shape, device=x.device, dtype=x.dtype) >= self.module_dropout).float()
            if keep.sum(dim=-1, keepdim=True).min().item() <= 0:
                fallback = torch.randint(0, keep.shape[-1], (keep.shape[0], 1), device=x.device)
                keep.scatter_(1, fallback, 1.0)
            gates = gates * keep / keep.mean(dim=-1, keepdim=True).clamp_min(1e-6)

        chunks = []
        for idx, (_, start, end) in enumerate(self.block_slices):
            chunks.append(x[..., start:end] * gates[..., idx:idx + 1])
        return torch.cat(chunks, dim=-1)

    def gate_balance_regularizer(self, x: torch.Tensor) -> torch.Tensor:
        if (not self.use_module_gates) or self.block_gate_logits is None or self.dynamic_gate is None or len(self.block_slices) <= 1:
            return x.new_zeros(())
        summaries = []
        for _name, start, end in self.block_slices:
            block = x[..., start:end]
            abs_block = block.abs()
            summaries.append(abs_block.mean(dim=-1, keepdim=True))
            summaries.append(torch.sqrt((block * block).mean(dim=-1, keepdim=True) + 1e-8))
            summaries.append((abs_block > 1e-8).float().mean(dim=-1, keepdim=True))
        dynamic_probs = F.softmax(self.dynamic_gate(torch.cat(summaries, dim=-1)), dim=-1)
        uniform = torch.full_like(dynamic_probs, 1.0 / float(dynamic_probs.shape[-1]))
        return torch.mean((dynamic_probs - uniform) ** 2)

    def forward(self, x):
        x = self._apply_module_gates(x)
        z = self.encoder(x)
        return self.classifier(z)


def get_update_param_names(model: nn.Module, scope: str = "all") -> List[str]:
    names = [name for name, p in model.named_parameters() if p.requires_grad]
    if scope == "all":
        return names
    if scope == "head":
        return [n for n in names if n.startswith("classifier")]
    raise ValueError(f"未知 inner_update_scope: {scope}")


def adapt_model(
    model: nn.Module,
    x_s: torch.Tensor,
    y_s: torch.Tensor,
    inner_steps: int,
    inner_lr: float,
    update_scope: str = "all",
):
    fast_weights = OrderedDict(model.named_parameters())
    update_names = get_update_param_names(model, update_scope)

    for _ in range(inner_steps):
        logits = functional_call(model, fast_weights, (x_s,))
        loss = F.cross_entropy(logits, y_s)
        grads = torch.autograd.grad(
            loss,
            [fast_weights[n] for n in update_names],
            create_graph=False,
            retain_graph=False,
        )
        new_fast = OrderedDict(fast_weights)
        for name, grad in zip(update_names, grads):
            new_fast[name] = fast_weights[name] - inner_lr * grad
        fast_weights = new_fast
    return fast_weights


@torch.no_grad()
def predict_with_adaptation(
    model: nn.Module,
    support_x: torch.Tensor,
    support_y: torch.Tensor,
    query_x: torch.Tensor,
    inner_steps: int,
    inner_lr: float,
    update_scope: str = "all",
    device: str = "cpu",
):
    model.eval()
    support_x = support_x.to(device)
    support_y = support_y.to(device)
    query_x = query_x.to(device)

    with torch.enable_grad():
        fast_weights = adapt_model(
            model,
            support_x,
            support_y,
            inner_steps=inner_steps,
            inner_lr=inner_lr,
            update_scope=update_scope,
        )

    logits = functional_call(model, fast_weights, (query_x,))
    probs = torch.softmax(logits, dim=-1)
    preds = torch.argmax(probs, dim=-1)
    return preds.cpu(), probs.cpu()


def evaluate_episodes(
    model: nn.Module,
    sampler: EpisodeSampler,
    num_episodes: int,
    inner_steps: int,
    inner_lr: float,
    update_scope: str,
    device: str = "cpu",
):
    model.eval()
    losses: List[float] = []
    accs: List[float] = []
    macro_precisions: List[float] = []
    macro_recalls: List[float] = []
    macro_f1s: List[float] = []

    for _ in range(num_episodes):
        x_s, y_s, x_q, y_q = sampler.sample_episode()
        x_s, y_s, x_q, y_q = x_s.to(device), y_s.to(device), x_q.to(device), y_q.to(device)

        fast_weights = adapt_model(
            model,
            x_s,
            y_s,
            inner_steps=inner_steps,
            inner_lr=inner_lr,
            update_scope=update_scope,
        )
        logits_q = functional_call(model, fast_weights, (x_q,))
        loss_q = F.cross_entropy(logits_q, y_q)
        pred_q = torch.argmax(logits_q, dim=-1)
        acc_q = (pred_q == y_q).float().mean().item()

        gold_list = y_q.detach().cpu().tolist()
        pred_list = pred_q.detach().cpu().tolist()
        active_label_ids = sorted(set(gold_list) | set(pred_list))
        metric = compute_classification_metrics(
            gold_list,
            pred_list,
            label_ids=active_label_ids,
        )
        losses.append(loss_q.item())
        accs.append(acc_q)
        macro_precisions.append(float(metric["macro_precision"]))
        macro_recalls.append(float(metric["macro_recall"]))
        macro_f1s.append(float(metric["macro_f1"]))

    return {
        "loss": float(np.mean(losses)) if losses else math.nan,
        "acc": float(np.mean(accs)) if accs else math.nan,
        "macro_precision": float(np.mean(macro_precisions)) if macro_precisions else math.nan,
        "macro_recall": float(np.mean(macro_recalls)) if macro_recalls else math.nan,
        "macro_f1": float(np.mean(macro_f1s)) if macro_f1s else math.nan,
        "episodes": num_episodes,
    }


def evaluate_prediction_rows(
    rows: List[Dict[str, Any]],
    label_names: Optional[Sequence[str]] = None,
) -> Optional[Dict[str, Any]]:
    golds = [int(r["gold"]) for r in rows if "gold" in r]
    preds = [int(r["pred"]) for r in rows if "gold" in r]
    if not golds:
        return None

    label_ids = list(range(len(label_names))) if label_names is not None else None
    report = compute_classification_metrics(golds, preds, label_names=label_names, label_ids=label_ids)
    report["num_query_samples"] = report.pop("num_samples")
    report["note"] = "该评估基于固定 support 集适配后对当前 query 集的逐样本预测结果。"
    return report


def _split_unique_values(values: Optional[List[str]], indices: List[int]) -> List[str]:
    if values is None:
        return []
    out = []
    seen = set()
    for i in indices:
        v = str(values[i]) if i < len(values) else ""
        if not v:
            continue
        if v not in seen:
            seen.add(v)
            out.append(v)
    return out


def analyze_split_overlap(
    train_idx: List[int],
    val_idx: List[int],
    test_idx: List[int],
    proc_names: List[str],
    group_ids: Optional[List[str]] = None,
    code_group_ids: Optional[List[str]] = None,
    template_family_ids: Optional[List[str]] = None,
) -> Dict[str, Any]:
    def _unique_from_indices(src: Optional[List[str]], idxs: List[int]) -> set:
        if src is None:
            return set()
        vals = set()
        for i in idxs:
            if i < len(src):
                v = str(src[i])
                if v:
                    vals.add(v)
        return vals

    analysis: Dict[str, Any] = {
        "num_train_samples": len(train_idx),
        "num_val_samples": len(val_idx),
        "num_test_samples": len(test_idx),
    }

    train_groups = _unique_from_indices(group_ids, train_idx)
    test_groups = _unique_from_indices(group_ids, test_idx)
    val_groups = _unique_from_indices(group_ids, val_idx)
    train_template = _unique_from_indices(template_family_ids, train_idx)
    test_template = _unique_from_indices(template_family_ids, test_idx)
    val_template = _unique_from_indices(template_family_ids, val_idx)
    train_code = _unique_from_indices(code_group_ids, train_idx)
    test_code = _unique_from_indices(code_group_ids, test_idx)
    val_code = _unique_from_indices(code_group_ids, val_idx)

    analysis.update({
        "group_id_overlap_train_test": sorted(train_groups & test_groups),
        "group_id_overlap_train_val": sorted(train_groups & val_groups),
        "group_id_overlap_val_test": sorted(val_groups & test_groups),
        "template_family_overlap_train_test": sorted(train_template & test_template),
        "template_family_overlap_train_val": sorted(train_template & val_template),
        "template_family_overlap_val_test": sorted(val_template & test_template),
        "code_hash_overlap_train_test": sorted(train_code & test_code),
        "code_hash_overlap_train_val": sorted(train_code & val_code),
        "code_hash_overlap_val_test": sorted(val_code & test_code),
        "num_group_ids": {
            "train": len(train_groups),
            "val": len(val_groups),
            "test": len(test_groups),
        },
        "num_template_families": {
            "train": len(train_template),
            "val": len(val_template),
            "test": len(test_template),
        },
        "num_code_hashes": {
            "train": len(train_code),
            "val": len(val_code),
            "test": len(test_code),
        },
        "proc_name_examples": {
            "train": [proc_names[i] for i in train_idx[:10]],
            "val": [proc_names[i] for i in val_idx[:10]],
            "test": [proc_names[i] for i in test_idx[:10]],
        },
    })
    return analysis


def _build_episode_samplers_with_fallback(
    X: np.ndarray,
    y: np.ndarray,
    plan: Dict[int, Dict[str, int]],
    seed: int,
    n_way: int,
    k_shot: int,
    q_query: int,
    group_ids: Optional[List[str]],
    use_group_split: bool,
    group_split_scope: str,
    has_val: bool,
):
    attempts = []
    configs = []
    if use_group_split:
        configs.append((True, group_split_scope, "requested_group_split"))
        if group_split_scope == "global":
            configs.append((True, "per_class", "fallback_group_split_per_class"))
        configs.append((False, "global", "fallback_disable_group_split"))
    else:
        configs.append((False, group_split_scope, "requested_no_group_split"))

    last_err = None
    for use_g, scope, reason in configs:
        try:
            train_idx, val_idx, test_idx = stratified_split_indices(
                y,
                plan,
                seed=seed,
                group_ids=group_ids,
                use_group_split=use_g,
                group_split_scope=scope,
            )
            train_sampler = EpisodeSampler(X, y, train_idx, n_way=n_way, k_shot=k_shot, q_query=q_query, seed=seed + 11)
            val_sampler = EpisodeSampler(X, y, val_idx, n_way=n_way, k_shot=k_shot, q_query=q_query, seed=seed + 23) if has_val else None
            test_sampler = EpisodeSampler(X, y, test_idx, n_way=n_way, k_shot=k_shot, q_query=q_query, seed=seed + 37)
            return {
                "train_idx": train_idx,
                "val_idx": val_idx,
                "test_idx": test_idx,
                "train_sampler": train_sampler,
                "val_sampler": val_sampler,
                "test_sampler": test_sampler,
                "used_group_split": use_g,
                "used_group_split_scope": scope,
                "split_resolution": reason,
                "attempts": attempts,
            }
        except Exception as e:
            last_err = e
            attempts.append({
                "use_group_split": use_g,
                "group_split_scope": scope,
                "reason": reason,
                "error": str(e),
            })

    if last_err is not None:
        raise last_err
    raise RuntimeError("无法构造 episode samplers。")


def infer_train_vocab_indices_for_json(args) -> Optional[List[int]]:
    """Mirror train_json splitting so feature vocabs can be fit on train only."""
    labels_map = load_labels(args.labels_json)
    preferred_label_to_id = load_label_order(args.labels_json)
    samples = load_samples(
        args.input_json,
        labels_map=labels_map,
        require_label=True,
        skeleton_field=args.skeleton_field,
        dataset_label_to_id=preferred_label_to_id if preferred_label_to_id else None,
    )
    if not samples:
        return None
    y = np.array([int(sample.label) for sample in samples], dtype=np.int64)
    n_classes = len(np.unique(y))
    n_way = int(args.n_way) if int(args.n_way) > 0 else int(n_classes)
    plan, has_val = compute_split_plan(
        y,
        args.k_shot,
        args.q_query,
        force_no_val=args.force_no_val,
        val_per_class=args.val_per_class,
        test_per_class=args.test_per_class,
        min_train_per_class=args.min_train_per_class,
    )
    group_ids = [choose_group_id(sample, group_mode=args.group_mode)[0] for sample in samples]
    sampler_bundle = _build_episode_samplers_with_fallback(
        X=np.zeros((len(samples), 1), dtype=np.float32),
        y=y,
        plan=plan,
        seed=args.seed,
        n_way=n_way,
        k_shot=args.k_shot,
        q_query=args.q_query,
        group_ids=group_ids,
        use_group_split=(not args.disable_group_split),
        group_split_scope=args.group_split_scope,
        has_val=has_val,
    )
    return [int(i) for i in sampler_bundle["train_idx"]]


def train_maml(args):
    set_seed(args.seed)
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"

    X, y, proc_names, group_ids, npz_label_names, code_group_ids, template_family_ids = load_feature_npz_meta(args.input_npz)
    input_dim = X.shape[1]
    feature_block_dims = load_feature_block_dims(args.input_npz, input_dim=input_dim)
    n_classes = len(np.unique(y))
    label_names = npz_label_names or [str(i) for i in range(n_classes)]

    n_way = int(args.n_way) if int(args.n_way) > 0 else int(n_classes)
    if n_way > n_classes:
        raise ValueError(f"n_way={n_way} 不能大于总类别数 {n_classes}。")

    plan, has_val = compute_split_plan(
        y,
        args.k_shot,
        args.q_query,
        force_no_val=args.force_no_val,
        val_per_class=args.val_per_class,
        test_per_class=args.test_per_class,
        min_train_per_class=args.min_train_per_class,
    )
    use_group_split = bool(group_ids is not None) and (not args.disable_group_split)
    if group_ids is None and (not args.disable_group_split):
        print("[Warn] 输入 NPZ 不含 group_ids，无法按代码模板分组切分；将退回普通随机分层切分。")
    sampler_bundle = _build_episode_samplers_with_fallback(
        X=X,
        y=y,
        plan=plan,
        seed=args.seed,
        n_way=n_way,
        k_shot=args.k_shot,
        q_query=args.q_query,
        group_ids=group_ids,
        use_group_split=use_group_split,
        group_split_scope=args.group_split_scope,
        has_val=has_val,
    )
    train_idx = sampler_bundle["train_idx"]
    val_idx = sampler_bundle["val_idx"]
    test_idx = sampler_bundle["test_idx"]
    train_sampler = sampler_bundle["train_sampler"]
    val_sampler = sampler_bundle["val_sampler"]
    test_sampler = sampler_bundle["test_sampler"]

    heldout_val_available = bool(has_val and val_sampler is not None and len(val_idx) > 0)
    proxy_val_used = bool((not heldout_val_available) and (not args.force_no_val))
    proxy_val_sampler = None
    if proxy_val_used:
        proxy_val_sampler = EpisodeSampler(
            X,
            y,
            train_idx,
            n_way=n_way,
            k_shot=args.k_shot,
            q_query=args.q_query,
            seed=args.seed + 29,
        )

    model = MAMLMLP(
        input_dim=input_dim,
        hidden_dim=args.hidden_dim,
        embed_dim=args.embed_dim,
        dropout=args.dropout,
        n_classes=n_classes,
        feature_block_dims=feature_block_dims,
        use_module_gates=(not getattr(args, "disable_module_gates", False)),
        adaptive_module_gates=(not getattr(args, "disable_adaptive_module_gates", False)),
        module_dropout=(
            float(getattr(args, "module_dropout", 0.0))
            if (
                not getattr(args, "disable_key_nodes", False)
                and not getattr(args, "disable_anchors", False)
                and not getattr(args, "disable_skeleton", False)
            )
            else 0.0
        ),
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.meta_lr, weight_decay=args.weight_decay)

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    def _split_class_counts(indices: List[int]) -> Dict[int, int]:
        if not indices:
            return {}
        vals, cnts = np.unique(y[indices], return_counts=True)
        return {int(v): int(c) for v, c in zip(vals, cnts)}

    split_info = {
        "has_val": has_val,
        "heldout_val_available": heldout_val_available,
        "proxy_val_used": proxy_val_used,
        "val_mode": "heldout" if heldout_val_available else ("train_proxy" if proxy_val_used else "none"),
        "plan_per_class": plan,
        "split_strategy": {
            "group_split_requested": use_group_split,
            "group_split_scope_requested": args.group_split_scope,
            "group_split_used": sampler_bundle["used_group_split"],
            "group_split_scope_used": sampler_bundle["used_group_split_scope"],
            "split_resolution": sampler_bundle["split_resolution"],
            "attempts": sampler_bundle["attempts"],
            "val_per_class_requested": int(args.val_per_class),
            "test_per_class_requested": int(args.test_per_class),
            "min_train_per_class_requested": int(args.min_train_per_class),
            "n_way": int(n_way),
            "heldout_val_available": heldout_val_available,
            "proxy_val_used": proxy_val_used,
            "val_mode": "heldout" if heldout_val_available else ("train_proxy" if proxy_val_used else "none"),
        },
        "label_names": label_names,
        "actual_per_class": {
            "train": _split_class_counts(train_idx),
            "val": _split_class_counts(val_idx),
            "test": _split_class_counts(test_idx),
        },
        "split_overlap_analysis": analyze_split_overlap(
            train_idx=train_idx,
            val_idx=val_idx,
            test_idx=test_idx,
            proc_names=proc_names,
            group_ids=group_ids,
            code_group_ids=code_group_ids,
            template_family_ids=template_family_ids,
        ),
        "train_idx": train_idx,
        "val_idx": val_idx,
        "test_idx": test_idx,
        "train_proc_names": [proc_names[i] for i in train_idx],
        "val_proc_names": [proc_names[i] for i in val_idx],
        "test_proc_names": [proc_names[i] for i in test_idx],
        "train_template_family_ids": _split_unique_values(template_family_ids, train_idx),
        "val_template_family_ids": _split_unique_values(template_family_ids, val_idx),
        "test_template_family_ids": _split_unique_values(template_family_ids, test_idx),
    }
    (output_dir / "split_info.json").write_text(json.dumps(split_info, ensure_ascii=False, indent=2), encoding="utf-8")
    if sampler_bundle["split_resolution"] != ("requested_group_split" if use_group_split else "requested_no_group_split"):
        print(f"[Warn] split 策略已自动回退为 {sampler_bundle['split_resolution']} (used_group_split={sampler_bundle['used_group_split']}, scope={sampler_bundle['used_group_split_scope']})")

    config = vars(args).copy()
    config.update(
        {
            "input_dim": int(input_dim),
            "feature_extractor": str(getattr(args, "feature_extractor_used", getattr(args, "feature_extractor", "structural"))),
            "plm_model_name_or_path": getattr(args, "plm_model_name_or_path", None),
            "plm_max_length": int(getattr(args, "plm_max_length", 512)),
            "plm_batch_size": int(getattr(args, "plm_batch_size", 8)),
            "plm_pooling": str(getattr(args, "plm_pooling", "cls")),
            "plm_l2_normalize": bool(getattr(args, "plm_l2_normalize", False)),
            "feature_block_dims": feature_block_dims,
            "module_gates_enabled": bool(feature_block_dims and not getattr(args, "disable_module_gates", False)),
            "adaptive_module_gates_enabled": bool(
                feature_block_dims
                and not getattr(args, "disable_module_gates", False)
                and not getattr(args, "disable_adaptive_module_gates", False)
            ),
            "module_dropout_used": (
                float(getattr(args, "module_dropout", 0.0))
                if (
                    not getattr(args, "disable_key_nodes", False)
                    and not getattr(args, "disable_anchors", False)
                    and not getattr(args, "disable_skeleton", False)
                )
                else 0.0
            ),
            "n_classes": int(n_classes),
            "n_way_used": int(n_way),
            "device_used": device,
            "has_val": has_val,
            "group_split_used": sampler_bundle["used_group_split"],
            "group_split_scope_used": sampler_bundle["used_group_split_scope"],
            "feature_switches": normalize_feature_switches(
                use_key_nodes=(not getattr(args, "disable_key_nodes", False)),
                use_anchors=(not getattr(args, "disable_anchors", False)),
                use_skeleton=(not getattr(args, "disable_skeleton", False)),
            ),
            "label_names": label_names,
            "id_to_label": {str(i): name for i, name in enumerate(label_names)},
            "label_to_id": {name: i for i, name in enumerate(label_names)},
        }
    )
    (output_dir / "train_config.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

    history: List[Dict[str, Any]] = []
    best_metric = -1e18
    best_epoch = -1
    best_ckpt_path = output_dir / "best_model.pt"

    for epoch in range(1, args.meta_epochs + 1):
        model.train()
        meta_losses: List[float] = []
        meta_accs: List[float] = []
        meta_macro_precisions: List[float] = []
        meta_macro_recalls: List[float] = []
        meta_macro_f1s: List[float] = []

        optimizer.zero_grad()

        for _ in range(args.meta_batch_size):
            x_s, y_s, x_q, y_q = train_sampler.sample_episode()
            x_s, y_s, x_q, y_q = x_s.to(device), y_s.to(device), x_q.to(device), y_q.to(device)

            fast_weights = adapt_model(
                model,
                x_s,
                y_s,
                inner_steps=args.inner_steps,
                inner_lr=args.inner_lr,
                update_scope=args.inner_update_scope,
            )

            logits_q = functional_call(model, fast_weights, (x_q,))
            loss_q = F.cross_entropy(logits_q, y_q)
            gate_balance_lambda = float(getattr(args, "gate_balance_lambda", 0.0))
            if gate_balance_lambda > 0.0 and hasattr(model, "gate_balance_regularizer"):
                loss_q = loss_q + (gate_balance_lambda * model.gate_balance_regularizer(x_q))
            (loss_q / args.meta_batch_size).backward()

            pred_q = torch.argmax(logits_q, dim=-1)
            acc_q = (pred_q == y_q).float().mean().item()
            metric_q = compute_classification_metrics(
                y_q.detach().cpu().tolist(),
                pred_q.detach().cpu().tolist(),
                label_names=label_names,
            )

            meta_losses.append(loss_q.item())
            meta_accs.append(acc_q)
            meta_macro_precisions.append(float(metric_q["macro_precision"]))
            meta_macro_recalls.append(float(metric_q["macro_recall"]))
            meta_macro_f1s.append(float(metric_q["macro_f1"]))

        torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
        optimizer.step()

        train_metrics = {
            "loss": float(np.mean(meta_losses)),
            "acc": float(np.mean(meta_accs)),
            "macro_precision": float(np.mean(meta_macro_precisions)),
            "macro_recall": float(np.mean(meta_macro_recalls)),
            "macro_f1": float(np.mean(meta_macro_f1s)),
        }

        if heldout_val_available and val_sampler is not None:
            val_metrics = evaluate_episodes(
                model,
                val_sampler,
                num_episodes=args.eval_episodes,
                inner_steps=args.inner_steps,
                inner_lr=args.inner_lr,
                update_scope=args.inner_update_scope,
                device=device,
            )
            val_mode = "heldout"
            monitor = val_metrics[args.monitor_metric]

            if monitor > best_metric:
                best_metric = monitor
                best_epoch = epoch
                torch.save(
                    {
                        "model_state": model.state_dict(),
                        "config": config,
                        "split_info": split_info,
                        "best_epoch": best_epoch,
                        "best_metric": best_metric,
                        "selection_strategy": f"best_val_{args.monitor_metric}",
                    },
                    best_ckpt_path,
                )
        elif proxy_val_used and proxy_val_sampler is not None:
            val_metrics = evaluate_episodes(
                model,
                proxy_val_sampler,
                num_episodes=args.eval_episodes,
                inner_steps=args.inner_steps,
                inner_lr=args.inner_lr,
                update_scope=args.inner_update_scope,
                device=device,
            )
            val_mode = "train_proxy"
            monitor = val_metrics[args.monitor_metric]

            if monitor > best_metric:
                best_metric = monitor
                best_epoch = epoch
                torch.save(
                    {
                        "model_state": model.state_dict(),
                        "config": config,
                        "split_info": split_info,
                        "best_epoch": best_epoch,
                        "best_metric": best_metric,
                        "selection_strategy": f"best_proxy_val_{args.monitor_metric}",
                    },
                    best_ckpt_path,
                )
        else:
            val_metrics = None
            val_mode = "none"

        history.append(
            {
                "epoch": epoch,
                "train_loss": train_metrics["loss"],
                "train_acc": train_metrics["acc"],
                "train_macro_precision": train_metrics["macro_precision"],
                "train_macro_recall": train_metrics["macro_recall"],
                "train_macro_f1": train_metrics["macro_f1"],
                "val_loss": None if val_metrics is None else val_metrics["loss"],
                "val_acc": None if val_metrics is None else val_metrics["acc"],
                "val_macro_precision": None if val_metrics is None else val_metrics["macro_precision"],
                "val_macro_recall": None if val_metrics is None else val_metrics["macro_recall"],
                "val_macro_f1": None if val_metrics is None else val_metrics["macro_f1"],
                "val_mode": val_mode,
                "best_metric_so_far": best_metric,
                "best_epoch_so_far": best_epoch,
            }
        )

        if epoch % args.log_every == 0 or epoch == 1 or epoch == args.meta_epochs:
            if val_metrics is None:
                print(
                    f"[Epoch {epoch:03d}] train_loss={train_metrics['loss']:.4f} "
                    f"train_acc={train_metrics['acc']:.4f} train_macro_precision={train_metrics['macro_precision']:.4f} "
                    f"train_macro_recall={train_metrics['macro_recall']:.4f} train_macro_f1={train_metrics['macro_f1']:.4f} best={best_metric:.4f}"
                )
            else:
                val_tag = "proxy_val" if val_mode == "train_proxy" else "val"
                print(
                    f"[Epoch {epoch:03d}] train_loss={train_metrics['loss']:.4f} "
                    f"train_acc={train_metrics['acc']:.4f} train_macro_precision={train_metrics['macro_precision']:.4f} "
                    f"train_macro_recall={train_metrics['macro_recall']:.4f} train_macro_f1={train_metrics['macro_f1']:.4f} "
                    f"{val_tag}_loss={val_metrics['loss']:.4f} {val_tag}_acc={val_metrics['acc']:.4f} "
                    f"{val_tag}_macro_precision={val_metrics['macro_precision']:.4f} {val_tag}_macro_recall={val_metrics['macro_recall']:.4f} "
                    f"{val_tag}_macro_f1={val_metrics['macro_f1']:.4f} best={best_metric:.4f}"
                )

    (output_dir / "train_history.json").write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding="utf-8")

    if best_epoch < 0:
        best_epoch = args.meta_epochs
        if history and proxy_val_used and history[-1]["val_macro_f1"] is not None:
            best_metric = float(history[-1][f"val_{args.monitor_metric}"])
            selection_strategy = f"last_proxy_val_{args.monitor_metric}"
        else:
            best_metric = float(history[-1][f"train_{args.monitor_metric}"]) if history else math.nan
            selection_strategy = f"last_epoch_no_val_{args.monitor_metric}"
        torch.save(
            {
                "model_state": model.state_dict(),
                "config": config,
                "split_info": split_info,
                "best_epoch": best_epoch,
                "best_metric": best_metric,
                "selection_strategy": selection_strategy,
            },
            best_ckpt_path,
        )

    ckpt = torch.load(best_ckpt_path, map_location=device)
    model.load_state_dict(ckpt["model_state"])
    module_gates = None
    if getattr(model, "use_module_gates", False) and getattr(model, "block_gate_logits", None) is not None:
        gate_values = F.softplus(model.block_gate_logits.detach()).cpu().tolist()
        module_gates = {
            name: float(value)
            for value, (name, _start, _end) in zip(gate_values, model.block_slices)
        }

    test_metrics = evaluate_episodes(
        model,
        test_sampler,
        num_episodes=args.test_episodes,
        inner_steps=args.inner_steps,
        inner_lr=args.inner_lr,
        update_scope=args.inner_update_scope,
        device=device,
    )

    final_report = {
        "best_epoch": best_epoch,
        "best_metric": best_metric,
        "monitor_metric": args.monitor_metric,
        "has_val": has_val,
        "heldout_val_available": heldout_val_available,
        "proxy_val_used": proxy_val_used,
        "val_mode": "heldout" if heldout_val_available else ("train_proxy" if proxy_val_used else "none"),
        "n_classes": n_classes,
        "n_way_used": n_way,
        "label_names": label_names,
        "group_split_used": sampler_bundle["used_group_split"],
        "group_split_scope_used": sampler_bundle["used_group_split_scope"],
        "feature_switches": config.get("feature_switches", normalize_feature_switches()),
        "feature_switch_tag": feature_switches_to_tag(config.get("feature_switches", normalize_feature_switches())),
        "feature_block_dims": feature_block_dims,
        "module_gates": module_gates,
        "adaptive_module_gates_enabled": bool(config.get("adaptive_module_gates_enabled", False)),
        "module_dropout_used": float(config.get("module_dropout_used", 0.0)),
        "split_resolution": sampler_bundle["split_resolution"],
        "split_overlap_analysis": split_info.get("split_overlap_analysis", {}),
        "test_accuracy": test_metrics["acc"],
        "test_macro_precision": test_metrics["macro_precision"],
        "test_macro_recall": test_metrics["macro_recall"],
        "test_macro_f1": test_metrics["macro_f1"],
        "test_metrics": test_metrics,
        "note": "few-shot test metrics are episode-averaged; results are more meaningful under the multiclass meta-task setting.",
    }
    (output_dir / "final_report.json").write_text(json.dumps(final_report, ensure_ascii=False, indent=2), encoding="utf-8")

    print("训练完成")
    print(json.dumps(final_report, ensure_ascii=False, indent=2))


def predict_mode(args):
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    ckpt = torch.load(args.checkpoint, map_location=device)
    config = ckpt["config"]
    label_names = [str(x) for x in config.get("label_names", [])]

    Xs, ys, s_names = load_feature_npz(args.support_npz, require_y=True)
    Xq, yq, q_names = load_feature_npz(args.query_npz, require_y=False)
    if ys is None:
        raise ValueError("support_npz 必须包含 y 标签。")

    input_dim = Xs.shape[1]
    model = MAMLMLP(
        input_dim=input_dim,
        hidden_dim=config["hidden_dim"],
        embed_dim=config["embed_dim"],
        dropout=config["dropout"],
        n_classes=config["n_classes"],
        feature_block_dims=config.get("feature_block_dims"),
        use_module_gates=bool(config.get("module_gates_enabled", False)),
        adaptive_module_gates=bool(config.get("adaptive_module_gates_enabled", False)),
        module_dropout=0.0,
    ).to(device)
    model.load_state_dict(ckpt["model_state"])

    support_x = torch.tensor(Xs, dtype=torch.float32)
    support_y = torch.tensor(ys, dtype=torch.long)
    query_x = torch.tensor(Xq, dtype=torch.float32)

    preds, probs = predict_with_adaptation(
        model,
        support_x=support_x,
        support_y=support_y,
        query_x=query_x,
        inner_steps=config["inner_steps"],
        inner_lr=config["inner_lr"],
        update_scope=config["inner_update_scope"],
        device=device,
    )

    rows: List[Dict[str, Any]] = []
    has_gold = yq is not None and len(yq) == len(q_names)
    for i, name in enumerate(q_names):
        class_probs = {label_names[j] if j < len(label_names) else str(j): float(probs[i, j].item()) for j in range(probs.shape[1])}
        row = {
            "proc_name": str(name),
            "pred": int(preds[i].item()),
            "pred_label": label_names[int(preds[i].item())] if int(preds[i].item()) < len(label_names) else str(int(preds[i].item())),
            "class_probs": class_probs,
        }
        if has_gold and yq is not None:
            row["gold"] = int(yq[i])
            if int(yq[i]) < len(label_names):
                row["gold_label"] = label_names[int(yq[i])]
        rows.append(row)

    output_path = Path(args.output_json)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"预测完成，已保存到 {output_path}")

    if getattr(args, "eval_report_json", None):
        eval_report = evaluate_prediction_rows(rows, label_names=label_names)
        if eval_report is None:
            print("[Info] query_npz 未提供真实标签，跳过评估报告写出。")
        else:
            eval_path = Path(args.eval_report_json)
            eval_path.parent.mkdir(parents=True, exist_ok=True)
            eval_path.write_text(json.dumps(eval_report, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"评估报告已保存到 {eval_path}")


# =========================
# Part C. Integrated entrypoints
# =========================


def build_features_mode(args):
    info = build_features_from_json(
        input_json=args.input_json,
        labels_json=args.labels_json,
        output_dir=args.output_dir,
        run_baseline_flag=args.run_baseline,
        skeleton_field=args.skeleton_field,
        group_mode=args.group_mode,
        use_key_nodes=(not args.disable_key_nodes),
        use_anchors=(not args.disable_anchors),
        use_skeleton=(not args.disable_skeleton),
        feature_extractor=getattr(args, "feature_extractor", "structural"),
        plm_model_name_or_path=getattr(args, "plm_model_name_or_path", None),
        plm_max_length=getattr(args, "plm_max_length", 512),
        plm_batch_size=getattr(args, "plm_batch_size", 8),
        plm_pooling=getattr(args, "plm_pooling", "cls"),
        plm_l2_normalize=getattr(args, "plm_l2_normalize", False),
        cpu=getattr(args, "cpu", False),
    )
    print(f"完成：已输出到 {args.output_dir}")
    print(f"样本数: {info['num_samples']}")
    print(f"特征提取器: {info.get('feature_extractor', 'structural')}")
    if info.get("feature_extractor", "structural") == "structural":
        print(f"关键节点词表大小: {info['key_vocab_size']}")
        print(f"锚点词表大小: {info['anchor_vocab_size']}")
        print(f"骨架 bigram 词表大小: {info['bigram_vocab_size']}")
        print(f"特征开关: {info['feature_switches']}")
        print(f"消融标签: {info['feature_switch_tag']}")
    else:
        print(f"PLM模型: {info.get('plm_model_name_or_path', '')}")
        print(f"PLM pooling: {info.get('plm_pooling', 'cls')}")
        print(f"PLM max_length: {info.get('plm_max_length', 512)}")
    print(f"最终特征维度: {info['input_dim']}")
    print(f"代码模板组数: {info['num_code_groups']}")
    print(f"类别数: {info['num_classes']}")
    print(f"类别名: {info['label_names']}")
    print(f"使用骨架字段: {info['skeleton_field']}")
    print(f"分组模式: {info['group_mode']}")

def train_json_mode(args):
    feature_extractor = getattr(args, "feature_extractor", "structural")
    vocab_sample_indices = None
    if feature_extractor == "structural" and not getattr(args, "disable_train_only_vocab", False):
        vocab_sample_indices = infer_train_vocab_indices_for_json(args)
    info = build_features_from_json(
        input_json=args.input_json,
        labels_json=args.labels_json,
        output_dir=args.output_dir,
        run_baseline_flag=args.run_baseline,
        skeleton_field=args.skeleton_field,
        group_mode=args.group_mode,
        use_key_nodes=(not args.disable_key_nodes),
        use_anchors=(not args.disable_anchors),
        use_skeleton=(not args.disable_skeleton),
        vocab_sample_indices=vocab_sample_indices,
        feature_extractor=feature_extractor,
        plm_model_name_or_path=getattr(args, "plm_model_name_or_path", None),
        plm_max_length=getattr(args, "plm_max_length", 512),
        plm_batch_size=getattr(args, "plm_batch_size", 8),
        plm_pooling=getattr(args, "plm_pooling", "cls"),
        plm_l2_normalize=getattr(args, "plm_l2_normalize", False),
        cpu=getattr(args, "cpu", False),
    )
    args.input_npz = info["npz_path"]
    args.vocab_source = info.get("vocab_source")
    args.feature_extractor_used = info.get("feature_extractor", feature_extractor)
    print(f"[Info] 已从 JSON 构建特征，特征提取器={info.get('feature_extractor', 'structural')}，NPZ 路径: {args.input_npz}")
    train_maml(args)

def predict_json_mode(args):
    device = "cuda" if torch.cuda.is_available() and not args.cpu else "cpu"
    ckpt = torch.load(args.checkpoint, map_location=device)
    config = ckpt["config"]

    feature_extractor = getattr(args, "feature_extractor", "auto")
    if feature_extractor == "auto":
        feature_extractor = str(config.get("feature_extractor_used") or config.get("feature_extractor") or "structural")
    feature_extractor = str(feature_extractor).lower()

    # PLM prediction path: support/query JSON are encoded directly from raw code.
    if feature_extractor in PLM_MODEL_NAMES:
        label_names = [str(x) for x in config.get("label_names", [])]
        label_to_id = {name: i for i, name in enumerate(label_names)}

        support_labels_map = load_labels(args.support_labels_json)
        support_samples = load_samples(
            args.support_json,
            labels_map=support_labels_map,
            require_label=True,
            skeleton_field=args.skeleton_field,
            dataset_label_to_id=label_to_id if label_to_id else None,
        )
        query_labels_map = load_labels(args.query_labels_json) if args.query_labels_json else {}
        query_samples = load_samples(
            args.query_json,
            labels_map=query_labels_map,
            require_label=False,
            default_label=-1,
            skeleton_field=args.skeleton_field,
            dataset_label_to_id=label_to_id if label_to_id else None,
        )

        model_name_or_path = getattr(args, "plm_model_name_or_path", None) or config.get("plm_model_name_or_path")
        max_length = int(getattr(args, "plm_max_length", 0) or config.get("plm_max_length", 512))
        batch_size = int(getattr(args, "plm_batch_size", 0) or config.get("plm_batch_size", 8))
        pooling = str(getattr(args, "plm_pooling", None) or config.get("plm_pooling", "cls"))
        l2_norm = bool(getattr(args, "plm_l2_normalize", False) or config.get("plm_l2_normalize", False))

        Xs, _ = extract_plm_embeddings(
            [sample.code for sample in support_samples],
            feature_extractor=feature_extractor,
            model_name_or_path=model_name_or_path,
            max_length=max_length,
            batch_size=batch_size,
            pooling=pooling,
            l2_normalize=l2_norm,
            device=device,
        )
        Xq, _ = extract_plm_embeddings(
            [sample.code for sample in query_samples],
            feature_extractor=feature_extractor,
            model_name_or_path=model_name_or_path,
            max_length=max_length,
            batch_size=batch_size,
            pooling=pooling,
            l2_normalize=l2_norm,
            device=device,
        )
        ys = np.array([int(sample.label) for sample in support_samples], dtype=np.int64)
        yq_raw = np.array([int(sample.label) for sample in query_samples], dtype=np.int64)
        has_gold = args.query_labels_json is not None or any(int(s.label) >= 0 for s in query_samples)

        model = MAMLMLP(
            input_dim=Xs.shape[1],
            hidden_dim=config["hidden_dim"],
            embed_dim=config["embed_dim"],
            dropout=config["dropout"],
            n_classes=config["n_classes"],
            feature_block_dims=config.get("feature_block_dims"),
            use_module_gates=bool(config.get("module_gates_enabled", False)),
            adaptive_module_gates=bool(config.get("adaptive_module_gates_enabled", False)),
            module_dropout=0.0,
        ).to(device)
        model.load_state_dict(ckpt["model_state"])

        preds, probs = predict_with_adaptation(
            model,
            support_x=torch.tensor(Xs, dtype=torch.float32),
            support_y=torch.tensor(ys, dtype=torch.long),
            query_x=torch.tensor(Xq, dtype=torch.float32),
            inner_steps=config["inner_steps"],
            inner_lr=config["inner_lr"],
            update_scope=config["inner_update_scope"],
            device=device,
        )

        rows: List[Dict[str, Any]] = []
        for i, sample in enumerate(query_samples):
            class_probs = {label_names[j] if j < len(label_names) else str(j): float(probs[i, j].item()) for j in range(probs.shape[1])}
            row = {
                "sample_id": sample.sample_id,
                "proc_name": sample.proc_name,
                "feature_extractor": feature_extractor,
                "pred": int(preds[i].item()),
                "pred_label": label_names[int(preds[i].item())] if int(preds[i].item()) < len(label_names) else str(int(preds[i].item())),
                "class_probs": class_probs,
            }
            gold_value = int(yq_raw[i])
            if has_gold and gold_value >= 0:
                row["gold"] = gold_value
                if gold_value < len(label_names):
                    row["gold_label"] = label_names[gold_value]
            rows.append(row)

        output_path = Path(args.output_json)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"预测完成，已保存到 {output_path}")

        if getattr(args, "eval_report_json", None):
            eval_report = evaluate_prediction_rows(rows, label_names=label_names)
            if eval_report is None:
                print("[Info] query_json 未提供真实标签，跳过评估报告写出。")
            else:
                eval_path = Path(args.eval_report_json)
                eval_path.parent.mkdir(parents=True, exist_ok=True)
                eval_path.write_text(json.dumps(eval_report, ensure_ascii=False, indent=2), encoding="utf-8")
                print(f"评估报告已保存到 {eval_path}")
        return

    # Structural prediction path: same as the original code.
    if not args.vocabs_json:
        raise ValueError("structural 特征预测需要提供 --vocabs_json；PLM 特征预测不需要该参数。")

    key_vocab, anchor_vocab, bigram_vocab, vocab_skeleton_field, vocab_label_names, vocab_feature_switches = load_vocabs(args.vocabs_json)
    skeleton_field = args.skeleton_field if args.skeleton_field != "auto" else vocab_skeleton_field
    label_names = [str(x) for x in (config.get("label_names") or vocab_label_names or [])]
    label_to_id = {name: i for i, name in enumerate(label_names)}

    support_labels_map = load_labels(args.support_labels_json)
    support_samples = load_samples(
        args.support_json,
        labels_map=support_labels_map,
        require_label=True,
        skeleton_field=skeleton_field,
        dataset_label_to_id=label_to_id if label_to_id else None,
    )
    support_rows = vectorize_samples(
        support_samples,
        key_vocab,
        anchor_vocab,
        bigram_vocab,
        use_key_nodes=vocab_feature_switches["use_key_nodes"],
        use_anchors=vocab_feature_switches["use_anchors"],
        use_skeleton=vocab_feature_switches["use_skeleton"],
    )
    Xs, ys, _ = rows_to_arrays(support_rows)

    query_labels_map = load_labels(args.query_labels_json) if args.query_labels_json else {}
    query_samples = load_samples(
        args.query_json,
        labels_map=query_labels_map,
        require_label=False,
        default_label=-1,
        skeleton_field=skeleton_field,
        dataset_label_to_id=label_to_id if label_to_id else None,
    )
    query_rows = vectorize_samples(
        query_samples,
        key_vocab,
        anchor_vocab,
        bigram_vocab,
        use_key_nodes=vocab_feature_switches["use_key_nodes"],
        use_anchors=vocab_feature_switches["use_anchors"],
        use_skeleton=vocab_feature_switches["use_skeleton"],
    )
    Xq, yq_raw, _ = rows_to_arrays(query_rows)
    has_gold = args.query_labels_json is not None or any(int(s.label) >= 0 for s in query_samples)

    model = MAMLMLP(
        input_dim=Xs.shape[1],
        hidden_dim=config["hidden_dim"],
        embed_dim=config["embed_dim"],
        dropout=config["dropout"],
        n_classes=config["n_classes"],
        feature_block_dims=config.get("feature_block_dims"),
        use_module_gates=bool(config.get("module_gates_enabled", False)),
        adaptive_module_gates=bool(config.get("adaptive_module_gates_enabled", False)),
        module_dropout=0.0,
    ).to(device)
    model.load_state_dict(ckpt["model_state"])

    support_x = torch.tensor(Xs, dtype=torch.float32)
    support_y = torch.tensor(ys, dtype=torch.long)
    query_x = torch.tensor(Xq, dtype=torch.float32)

    preds, probs = predict_with_adaptation(
        model,
        support_x=support_x,
        support_y=support_y,
        query_x=query_x,
        inner_steps=config["inner_steps"],
        inner_lr=config["inner_lr"],
        update_scope=config["inner_update_scope"],
        device=device,
    )

    rows: List[Dict[str, Any]] = []
    for i, sample in enumerate(query_samples):
        class_probs = {label_names[j] if j < len(label_names) else str(j): float(probs[i, j].item()) for j in range(probs.shape[1])}
        row = {
            "sample_id": sample.sample_id,
            "proc_name": sample.proc_name,
            "pred": int(preds[i].item()),
            "pred_label": label_names[int(preds[i].item())] if int(preds[i].item()) < len(label_names) else str(int(preds[i].item())),
            "class_probs": class_probs,
        }
        gold_value = int(yq_raw[i])
        if has_gold and gold_value >= 0:
            row["gold"] = gold_value
            if gold_value < len(label_names):
                row["gold_label"] = label_names[gold_value]
        rows.append(row)

    output_path = Path(args.output_json)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"预测完成，已保存到 {output_path}")

    if getattr(args, "eval_report_json", None):
        eval_report = evaluate_prediction_rows(rows, label_names=label_names)
        if eval_report is None:
            print("[Info] query_json 未提供真实标签，跳过评估报告写出。")
        else:
            eval_path = Path(args.eval_report_json)
            eval_path.parent.mkdir(parents=True, exist_ok=True)
            eval_path.write_text(json.dumps(eval_report, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"评估报告已保存到 {eval_path}")

def add_train_common_args(p):
    p.add_argument("--output_dir", type=str, required=True, help="输出目录")
    p.add_argument("--n_way", type=int, default=0, help="每个 episode 采样的类别数；0 表示默认使用全部类别")
    p.add_argument("--k_shot", type=int, default=1, help="support set 每类样本数")
    p.add_argument("--q_query", type=int, default=1, help="query set 每类样本数")
    p.add_argument("--meta_epochs", type=int, default=200)
    p.add_argument("--meta_batch_size", type=int, default=4)
    p.add_argument("--eval_episodes", type=int, default=30)
    p.add_argument("--test_episodes", type=int, default=50)
    p.add_argument("--val_per_class", type=int, default=10, help="每类 validation 目标样本数；数据较少时会自动回退")
    p.add_argument("--test_per_class", type=int, default=10, help="每类 test 目标样本数；数据较少时会自动回退")
    p.add_argument("--min_train_per_class", type=int, default=20, help="每类训练集期望至少保留的样本数；数据较少时会自动回退")
    p.add_argument("--disable_group_split", action="store_true", help="禁用按代码模板分组切分；默认若 NPZ 含 group_ids 则启用")
    p.add_argument("--group_split_scope", type=str, default="global", choices=["global", "per_class"], help="group_split 的作用范围；global 更适合把 safe/vuln 模板对整体绑在一起")
    p.add_argument("--inner_steps", type=int, default=1)
    p.add_argument("--inner_lr", type=float, default=0.01)
    p.add_argument("--meta_lr", type=float, default=1e-3)
    p.add_argument("--weight_decay", type=float, default=1e-4)
    p.add_argument("--hidden_dim", type=int, default=64)
    p.add_argument("--embed_dim", type=int, default=32)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--inner_update_scope", type=str, default="all", choices=["all", "head"])
    p.add_argument("--grad_clip", type=float, default=5.0)
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--log_every", type=int, default=10)
    p.add_argument("--monitor_metric", type=str, default="macro_f1", choices=["acc", "macro_f1"], help="validation 上用于挑选最佳 checkpoint 的指标")
    p.add_argument("--force_no_val", action="store_true", help="强制不划分 validation，只做 train/test")
    p.add_argument("--disable_module_gates", action="store_true", help="禁用 Full 模型中的 key/anchor/skeleton 模块 gate")
    p.add_argument("--disable_adaptive_module_gates", action="store_true", help="禁用样本级动态模块 gate，仅保留全局 gate")
    p.add_argument("--module_dropout", type=float, default=0.15, help="Full 训练时的 module-level dropout 概率；消融模型自动置 0")
    p.add_argument("--gate_balance_lambda", type=float, default=0.01, help="light regularization to discourage adaptive gates from collapsing onto a single module")
    p.add_argument("--cpu", action="store_true", help="强制使用 CPU")




def add_feature_ablation_args(p):
    p.add_argument("--disable_key_nodes", action="store_true", help="消融开关：关闭 key nodes 特征（维度保留，对应分量置零）")
    p.add_argument("--disable_anchors", action="store_true", help="消融开关：关闭 security anchors 特征；RQ3-v2 中 summary flags 默认关闭（维度保留，对应分量置零）")
    p.add_argument("--disable_skeleton", action="store_true", help="消融开关：关闭 skeleton bigram 特征（维度保留，对应分量置零）")


def add_plm_feature_args(p, default_feature_extractor: str = "codebert", allow_auto: bool = False, include_cpu: bool = False):
    choices = ["structural", "codebert", "graphcodebert", "unixcoder"]
    if allow_auto:
        choices = ["auto"] + choices
    p.add_argument(
        "--feature_extractor",
        type=str,
        default=default_feature_extractor,
        choices=choices,
        help="特征提取方式：structural 使用原 key nodes / anchors / skeleton；codebert/graphcodebert/unixcoder 使用冻结预训练模型编码原始 code。",
    )
    p.add_argument(
        "--plm_model_name_or_path",
        type=str,
        default=None,
        help="可选，本地模型路径或 HuggingFace 模型名；不填时自动使用 microsoft/codebert-base、microsoft/graphcodebert-base 或 microsoft/unixcoder-base。",
    )
    p.add_argument("--plm_max_length", type=int, default=512, help="PLM tokenizer 最大长度")
    p.add_argument("--plm_batch_size", type=int, default=8, help="PLM 特征提取 batch size")
    p.add_argument("--plm_pooling", type=str, default="cls", choices=["cls", "mean"], help="PLM 输出池化方式")
    p.add_argument("--plm_l2_normalize", action="store_true", help="是否对 PLM embedding 做 L2 normalize")
    if include_cpu:
        p.add_argument("--cpu", action="store_true", help="强制使用 CPU")

def build_parser():
    parser = argparse.ArgumentParser(
        description="All-in-one pipeline: structural / CodeBERT / GraphCodeBERT / UniXCoder feature building + first-order MAML training / prediction"
    )
    subparsers = parser.add_subparsers(dest="mode", required=True)

    # 1) build features only
    build_p = subparsers.add_parser("build_features", help="从原始 JSON 构建特征")
    build_p.add_argument("--input_json", type=str, required=True, help="输入 JSON 文件")
    build_p.add_argument("--labels_json", type=str, default=None, help="可选，sample_id/proc_name -> label 的 JSON 文件")
    build_p.add_argument("--output_dir", type=str, required=True, help="输出目录")
    build_p.add_argument("--run_baseline", action="store_true", help="是否运行 baseline 分类器")
    build_p.add_argument("--skeleton_field", type=str, default="auto", choices=["auto", "anchor_skeleton", "key_skeleton", "skeleton"], help="选择使用哪种骨架字段")
    build_p.add_argument("--group_mode", type=str, default="code_hash", choices=["code_hash", "template_family", "template_then_hash"], help="group_id 的生成方式；template_family 更适合做模板家族级切分")
    add_plm_feature_args(build_p, default_feature_extractor="codebert", include_cpu=True)
    add_feature_ablation_args(build_p)

    # 2) train from JSON directly
    train_json_p = subparsers.add_parser("train_json", help="从原始 JSON 直接训练 first-order MAML")
    train_json_p.add_argument("--input_json", type=str, required=True, help="输入 JSON 文件")
    train_json_p.add_argument("--labels_json", type=str, default=None, help="可选，sample_id/proc_name -> label 的 JSON 文件")
    train_json_p.add_argument("--run_baseline", action="store_true", help="是否在特征构建后顺便跑 baseline")
    train_json_p.add_argument("--skeleton_field", type=str, default="auto", choices=["auto", "anchor_skeleton", "key_skeleton", "skeleton"], help="选择使用哪种骨架字段")
    train_json_p.add_argument("--group_mode", type=str, default="code_hash", choices=["code_hash", "template_family", "template_then_hash"], help="group_id 的生成方式；template_family 更适合做模板家族级切分")
    train_json_p.add_argument("--disable_train_only_vocab", action="store_true", help="禁用 train-only vocab，退回全数据建词表；仅 structural 特征有效")
    add_plm_feature_args(train_json_p, default_feature_extractor="codebert", include_cpu=False)
    add_feature_ablation_args(train_json_p)
    add_train_common_args(train_json_p)

    # 3) keep old train from NPZ
    train_npz_p = subparsers.add_parser("train_npz", help="从 NPZ 训练 first-order MAML（兼容旧流程）")
    train_npz_p.add_argument("--input_npz", type=str, required=True, help="maml_ready_features.npz")
    add_train_common_args(train_npz_p)

    # 4) keep old predict from NPZ
    pred_npz_p = subparsers.add_parser("predict_npz", help="使用 NPZ 做 few-shot 预测（兼容旧流程）")
    pred_npz_p.add_argument("--checkpoint", type=str, required=True, help="best_model.pt")
    pred_npz_p.add_argument("--support_npz", type=str, required=True, help="带标签的 support set npz")
    pred_npz_p.add_argument("--query_npz", type=str, required=True, help="待预测 query set npz（可含 y）")
    pred_npz_p.add_argument("--output_json", type=str, required=True, help="预测输出 json")
    pred_npz_p.add_argument("--eval_report_json", type=str, default=None, help="可选，若 query_npz 含 gold，则额外输出评估报告")
    pred_npz_p.add_argument("--cpu", action="store_true", help="强制使用 CPU")

    # 5) predict from JSON directly with existing vocabs
    pred_json_p = subparsers.add_parser("predict_json", help="从原始 JSON 直接做 few-shot 预测")
    pred_json_p.add_argument("--checkpoint", type=str, required=True, help="best_model.pt")
    pred_json_p.add_argument("--vocabs_json", type=str, default=None, help="训练时输出的 vocabs.json；structural 特征需要，PLM 特征不需要")
    pred_json_p.add_argument("--support_json", type=str, required=True, help="带标签的 support JSON")
    pred_json_p.add_argument("--support_labels_json", type=str, default=None, help="可选，support 的标签 JSON；若 support_json 自带 dataset_label/binary_label 可省略")
    pred_json_p.add_argument("--query_json", type=str, required=True, help="待预测的 query JSON")
    pred_json_p.add_argument("--query_labels_json", type=str, default=None, help="可选，query 的标签 JSON；仅用于对照评估，不参与预测")
    pred_json_p.add_argument("--output_json", type=str, required=True, help="预测输出 json")
    pred_json_p.add_argument("--eval_report_json", type=str, default=None, help="可选，若提供 query_labels_json，则额外输出评估报告")
    pred_json_p.add_argument("--skeleton_field", type=str, default="auto", choices=["auto", "anchor_skeleton", "key_skeleton", "skeleton"], help="选择使用哪种骨架字段；auto 时优先沿用训练时词表记录")
    add_plm_feature_args(pred_json_p, default_feature_extractor="auto", allow_auto=True, include_cpu=False)
    pred_json_p.add_argument("--cpu", action="store_true", help="强制使用 CPU")

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if args.mode == "build_features":
        build_features_mode(args)
    elif args.mode == "train_json":
        train_json_mode(args)
    elif args.mode == "train_npz":
        train_maml(args)
    elif args.mode == "predict_npz":
        predict_mode(args)
    elif args.mode == "predict_json":
        predict_json_mode(args)
    else:
        raise ValueError(args.mode)


if __name__ == "__main__":
    main()
